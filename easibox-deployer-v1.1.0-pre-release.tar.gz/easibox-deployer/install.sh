# Parameters
while getopts c:hm opts; do
    case ${opts} in
        c) FORCE_EXEC=${OPTARG} ;;
        m) BLOCK_EASIBOX_MID_RESTART=1 ;;
        h)
            echo "Usage: install.sh [options...]
-c FUNC_NAME    Force the deployer to run a function and close
-m              Block restarting the EASiBox midware service
-h              Help"
            exit
            ;;
    esac
done

### Do not touch ### ----------------------------------------------------
DIR_BASE="$(cd "${0%/*}" && echo $PWD)"
source "$DIR_BASE/libs/init.sh"
### Do not touch ### ----------------------------------------------------

# Import menus
for file in $DIR_SCRIPTS/*; do
    source "$file"
done

# Import installation files
for file in $DIR_MENUS/*; do
    source "$file"
done

function rollMenu() {
    sudo clear

    sleep 0.2

    showHeader
}

function printSectionTitle() {
    local title=$1

    rollMenu
    printfTitle "$title"
    echo
}

function finishOption() {
    if [ "$FORCE_EXEC" = "" ]; then
        echo
        printfInfo "Finished. Press Enter to continue..."
        read -p "" </dev/tty
    fi
}

function configureGeneric() {
    # $1 = Configuration file
    # $2 = Configuration key
    # $3 = Configuration old value

    local filename=$1
    local key=$2
    local old_value=$3
    local value

    printSectionTitle "Type the new value:"

    echo
    read -p "$key: " value </dev/tty
    export "$key=$value"

    replaceStringInFile "$filename" "$key=$old_value" "$key=$value"
    replaceStringInFile "$filename" "$key=\"$old_value\"" "$key=\"$value\""
    replaceStringInFile "$filename" "$key='$old_value'" "$key='$value'"

    finishOption
}

# Start
if [ "$FORCE_EXEC" != "" ]; then
    $FORCE_EXEC
elif [ -z "$FACTORY_APPROVED_EASIBOX" ]; then
    showAllOptions
else
    showFactoryApprovedOptions
fi
