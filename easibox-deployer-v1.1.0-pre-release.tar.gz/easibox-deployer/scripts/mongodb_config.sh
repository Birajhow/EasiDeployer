function configureMongoDB() {
    printfInfo "Creating MongoDB conf file"

    local conf="
# Where and how to store data.
storage:
  dbPath: $DIR_MONGO_DATA_DB
  journal:
    enabled: true

# where to write logging data.
systemLog:
  destination: file
  logAppend: true
  path: $DIR_MONGO_DATA_LOGS/mongod.log

# network interfaces
net:
  port: 27017
  bindIp: 127.0.0.1

# how the process runs
processManagement:
  timeZoneInfo: /usr/share/zoneinfo
"

    if [ -f "$FILE_MONGO_CONF" ]; then
        sudo rm "$FILE_MONGO_CONF"
    fi

    echo "${conf}" | sudo tee -a "$FILE_MONGO_CONF" &>> /dev/null
}

function configureMongoDBComposeFile() {
    printfInfo "Creating MongoDB compose file"

    local compose="
version: '3.1'

networks:
  mongodbnet:

services:
  mongo:
    image: mongo:4
    ports:
      - $PORT_MONGO:27017
    volumes:
      - $DIR_MONGO_DATA:/data/db
      - $FILE_MONGO_CONF:/etc/mongodb.conf
    networks:
      - mongodbnet
    deploy:
      restart_policy:
        condition: any
        delay: 15s
        max_attempts: 30
        window: 500s
"

    if [ -f "$FILE_MONGO_COMPOSE" ]; then
        rm "$FILE_MONGO_COMPOSE"
    fi

    echo "${compose}" | tee -a "$FILE_MONGO_COMPOSE" &>> /dev/null
}
