function configureMosquitto() {
    printfInfo "Creating Mosquitto conf file"

    local conf="
max_inflight_messages 0
max_inflight_bytes 0
max_queued_messages 32000

listener $PORT_MQTT
protocol mqtt
log_type error warning
connection bridge-$MAC_FORMATTED_UPPERCASE
address $SERVER_MQTT:$PORT_MQTT
remote_username $MAC_FORMATTED_LOWERCASE
remote_password $LICENSE_KEY
remote_clientid broker-$MAC_FORMATTED_LOWERCASE
bridge_cafile $DIR_MQTT_CERTS/$FILENAME_CA
bridge_certfile $DIR_MQTT_CERTS/$FILENAME_CERT
bridge_keyfile $DIR_MQTT_CERTS/$FILENAME_KEY

bridge_insecure true
allow_anonymous true
require_certificate true

keepalive_interval 10

cleansession false
#try_private false
bridge_attempt_unsubscribe false

topic v1/store/$IDX_STORE/# both 2

cafile $DIR_MQTT_CERTS/$FILENAME_CA
certfile $DIR_MQTT_CERTS/$FILENAME_CERT
keyfile $DIR_MQTT_CERTS/$FILENAME_KEY
"

    if [ -f "$FILE_MQTT_CONF" ]; then
        sudo rm "$FILE_MQTT_CONF"
    fi

    echo "${conf}" | sudo tee -a "$FILE_MQTT_CONF" &>> /dev/null
}

function linkMosquittoCertificates() {
    printfInfo "Linking certificates to Mosquitto"

    createDirSudo "$DIR_MQTT_CERTS"

    if [ ! -z "$(ls -A "$DIR_MQTT_CERTS")" ]; then
        printfDebug "Removing old links"
        sudo rm "$DIR_MQTT_CERTS"/*
    fi

    isStringEmpty "$CONTENT_KEY"
    local is_key_empty=$?
    isStringEmpty "$CONTENT_CA"
    local is_ca_empty=$?
    isStringEmpty "$CONTENT_CERT"
    local is_cert_empty=$?

    if [ $is_key_empty -eq 0 ]; then
        sudo ln -d "$FILE_KEY" "$DIR_MQTT_CERTS/$FILENAME_KEY"
        printfDebug "Linked $FILENAME_KEY"
    else
        printfWarning 'No KEY certificate provided'
    fi

    if [ $is_ca_empty -eq 0 ]; then
        sudo ln -d "$FILE_CA" "$DIR_MQTT_CERTS/$FILENAME_CA"
        printfDebug "Linked $FILENAME_CA"
    else
        printfWarning 'No CA certificate provided'
    fi

    if [ $is_cert_empty -eq 0 ]; then
        sudo ln -d "$FILE_CERT" "$DIR_MQTT_CERTS/$FILENAME_CERT"
        printfDebug "Linked $FILENAME_CERT"
    else
        printfWarning 'No CERT certificate provided'
    fi

    sudo chown -R $USER_CURRENT:$USER_CURRENT "$DIR_MQTT_CERTS"
}