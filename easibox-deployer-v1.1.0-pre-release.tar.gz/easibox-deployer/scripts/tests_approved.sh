function waitBeforeTesting() {
    printfInfo "Waiting 7s..."
    sleep 7
}

function testIP() {
    if [ "$IP_INTERNAL_STATIC" = ""  ]; then
        printfWarning "The EASiBox IP must be static"
    else
        printfInfo "The EASiBox IP is static"
    fi
}

function testNTP() {
    if ntpq -p | grep -q "a.ntp.br"; then
        printfInfo "NTP is connected"
    else
        printfError "NTP is not connected"
    fi
}

function testOpenVPN() {
    if ip route | grep -q "10.8.0.0"; then
        printfInfo "OpenVPN is connected"
    else
        printfError "OpenVPN is not connected"
    fi
}

function testJanus() {
    local janusPID=$(pidof janus)

    if [ "$janusPID" = "" ]; then
        printfError "Janus isn't running"
        return
    fi

    local elapsed_janus=$(($(ps -p $janusPID -o etimes=) + 1))
    local janus_log=$(sudo journalctl --no-pager --since "$elapsed_janus seconds ago" -u janus)
    if echo "${janus_log}" | grep -q "New video stream"; then
        local missing_cameras_logs="$(echo "${janus_log}" | grep "RTSP stream failed")"

        if [ "$missing_cameras_logs" != "" ]; then
            local missing_cameras="$(echo "${missing_cameras_logs}" | grep -o -P '(?<=WARN\] \[).*?(?=\])' | xargs -n1 | sort -u | xargs)"

            printfWarning "Janus is reporting unreachable cameras: $missing_cameras"
        else
            printfInfo "Janus cameras are streamming"
        fi
    else
        printfWarning "Janus is reporting no connected cameras"
    fi
}

function testMosquitto() {
    local mosquittoPID=$(pidof mosquitto)

    if [ "$mosquittoPID" = "" ]; then
        printfError "Mosquitto isn't running"
        return
    fi

    local elapsed_mosquitto=$(($(ps -p $mosquittoPID -o etimes=) + 1))
    local mosquitto_log=$(sudo journalctl --no-pager --since "$elapsed_mosquitto seconds ago" -u snap.mosquitto.mosquitto)
    if echo "${mosquitto_log}" | grep -q "using insecure mode."; then
        printfInfo "Mosquitto is connected"
    else
        printfError "Mosquitto is not connected"
    fi
}

function testMongoDB() {
    if sudo docker stack ps mongo | grep -q "Running"; then
        printfInfo "MongoDB container is running"
    else
        printfError "MongoDB container is not running"
    fi
}

function testMySQL() {
    if sudo service mysql status | grep -q "active (running)"; then
        printfInfo "MySQL service is running"
    else
        printfError "MySQL service is not running"
    fi
}

function executeInstallationTests() {
    testIP
    testNTP
    testOpenVPN
    testJanus
    testMosquitto
    testMongoDB
    testMySQL
}
