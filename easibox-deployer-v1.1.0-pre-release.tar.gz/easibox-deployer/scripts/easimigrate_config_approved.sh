function setAdvancedDBBeys() {
    printfInfo "Setting advanced MySQL keys"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi

    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config" "MAX_UPLOAD_SPEED" "$MAX_UPLOAD_SPEED"
    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config" "FIX_SOCCIN" "$FIX_SOCCIN"
    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config" "VIDEO_AND_AUDIO" "$VIDEO_AND_AUDIO"
    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config" "CR_OVERLAY_ENABLED" "$CR_OVERLAY_ENABLED"
}

function setLiceseDBKey() {
    printfInfo "Setting license MySQL key"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi

    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config_sys" "_LICENSE_KEY" "$LICENSE_KEY"
}

function setVersionDBKey() {
    printfInfo "Setting version MySQL key"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi

    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config" "VERSION" "$VERSION_EASIBOX"
}

function setNetworkInterfaceDBKey() {
    printfInfo "Setting network interface MySQL key"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi
 
    if [ "$NETWORK_INTERFACE" = "" ]; then
        printfWarning "The network interface is empty, ignoring value update"
        return
    fi

    setkeyValue "$DATABASE_MYSQL" "tbl_cash_box_config_sys" "_NETWORK_IFACE" "$NETWORK_INTERFACE"
}

function setModule() {
    local name=$1
    local port=$2

    local key_exists=$(sudo mysql $DATABASE_MYSQL -se "SELECT idx FROM \`tbl_cash_system\` WHERE \`name\` = '$name'")

    local enabled=0

    if [ "$port" != "" ]; then
        enabled=1
    fi

    cd ~

    if [ "$key_exists" != "" ]; then
        echo "
            USE $DATABASE_MYSQL;
            UPDATE tbl_cash_system SET \`enabled\`='$enabled', \`port\`='$port' WHERE \`name\`='$name';
        " > temp.sql
    else
        echo "
            USE $DATABASE_MYSQL;
            INSERT INTO \`tbl_cash_system\`
                (\`name\`, \`enabled\`, \`ip\`, \`port\`)
            VALUES
                ('$name', $enabled, '0.0.0.0', '$port');
        " > temp.sql
    fi

    local res=$(sudo mysql < temp.sql 2>&1 >/dev/null)
    if echo $res | grep -q "ERROR"; then
        printfError "Failed to module $key"
        echo $res &>>"$FILE_LOG";
    else
        printfDebug "$name = $port"
    fi
    rm temp.sql
}

function setModules() {
    printfInfo "Setting module MySQL keys"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi

    setModule "UsCallVoip" "$PORT_USCALLVOIP"
    setModule "Default" "$PORT_DEFAULT"
    setModule "Topsistemas" "$PORT_TOPSISTEMAS"
    setModule "EasiAlarm" "$PORT_EASIALARM"
    setModule "EasiProductLineMovement" "$PORT_EASIPRODUCTLINEMOVEMENT"
}

function setNVRAndPOS() {
    printfInfo "Setting NVR and POS MySQL keys"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi

    cd ~

    local query_update=""

    local dvr_idx

    local pos
    local host_nvr
    local port_nvr
    local schema_nvr
    local user_nvr
    local password_nvr
    local port_rtsp_nvr
    local auth_mode_nvr
    local channel_camera_nvr
    local channel_extra_camera_nvr
    local brand_camera
    local idx_camera
    local audio_camera_nvr

    local camera_line_counter=0    

    local values_tbl_cash_dvr

    while read line; do
        if [ "$line" = "===" ]; then
            camera_line_counter=0

            echo "
                USE $DATABASE_MYSQL;
                INSERT INTO \`tbl_cash_dvr\`
                    (\`host\`, \`port\`, \`schema\`, \`user\`, \`password\`, \`ignore_certificate\`, \`rtsp_port\`,
                    \`brand\`, \`channel_id\`, \`auth_mode\`, \`camera_idx\`, \`audio\`, \`channel_extra\`)
                VALUES
                    ('$host_nvr', $port_nvr, '$schema_nvr', '$user_nvr', '$password_nvr', 1, $port_rtsp_nvr, $brand_camera,
                    '$channel_camera_nvr', $auth_mode_nvr, $idx_camera, $audio_camera_nvr, '$channel_extra_camera_nvr');
            " > temp.sql
            local res=$(sudo mysql < temp.sql 2>&1 >/dev/null)
            if echo $res | grep -q "ERROR"; then
                echo "
                    USE $DATABASE_MYSQL;
                    UPDATE \`tbl_cash_dvr\` SET
                        \`host\` = '$host_nvr',
                        \`port\` = $port_nvr,
                        \`schema\` = '$schema_nvr',
                        \`user\` = '$user_nvr',
                        \`password\` = '$password_nvr',
                        \`rtsp_port\` = $port_rtsp_nvr,
                        \`brand\` = $brand_camera,
                        \`channel_id\` = '$channel_camera_nvr',
                        \`auth_mode\` = $auth_mode_nvr,
                        \`audio\` = $audio_camera_nvr,
                        \`channel_extra\` = '$channel_extra_camera_nvr'
                    WHERE
                        \`camera_idx\` = $idx_camera;
                " > temp.sql
                res=$(sudo mysql < temp.sql 2>&1 >/dev/null)
                if echo $res | grep -q "ERROR"; then
                    printfError "Failed to set NVR configuration for POS $pos"
                    echo $res &>>"$FILE_LOG";
                else
                    printfDebug "Updated NVR configuration for POS $pos"
                fi
            else
                printfDebug "Inserted NVR configuration for POS $pos"
            fi
            rm temp.sql

            dvr_idx=$(sudo mysql $DATABASE_MYSQL -se "SELECT idx FROM \`tbl_cash_dvr\` WHERE \`camera_idx\` = $idx_camera")

            echo "
                USE $DATABASE_MYSQL;
                INSERT INTO \`tbl_cash_pos\`
                    (\`pos_code\`, \`dvr\`, \`enabled\`)
                VALUES
                    ($pos, $dvr_idx, 1);
            " > temp.sql
            local res=$(sudo mysql < temp.sql 2>&1 >/dev/null)
            if echo $res | grep -q "ERROR"; then
                echo "
                    USE $DATABASE_MYSQL;
                    UPDATE \`tbl_cash_pos\` SET
                        \`pos_code\` = $pos,
                        \`dvr\` = $dvr_idx,
                        \`enabled\` = 1
                    WHERE
                        \`pos_code\` = $pos;
                " > temp.sql
                res=$(sudo mysql < temp.sql 2>&1 >/dev/null)
                if echo $res | grep -q "ERROR"; then
                    printfError "Failed to set POS $pos configuration"
                    echo $res &>>"$FILE_LOG";
                    echo $res
                else
                    printfDebug "Updated POS $pos configuration"
                fi
            else
                printfDebug "Inserted POS $pos configuration"
            fi
            rm temp.sql

            pos=""
            host_nvr=""
            port_nvr=""
            schema_nvr=""
            user_nvr=""
            password_nvr=""
            auth_mode_nvr=""
            port_rtsp_nvr=""
            channel_camera_nvr=""
            channel_extra_camera_nvr=""
            brand_camera=""
            idx_camera=""
            audio_camera_nvr=""
        else
            camera_line_counter=$((camera_line_counter + 1))
            case $camera_line_counter in
                1)
                    pos="$line"
                    ;;
                2)
                    host_nvr="$line"
                    ;;
                3)
                    port_nvr="$line"
                    ;;
                4)
                    schema_nvr="$line"
                    ;;
                5)
                    user_nvr="$line"
                    ;;
                6)
                    password_nvr="$line"
                    ;;
                7)
                    port_rtsp_nvr="$line"
                    ;;
                8)
                    auth_mode_nvr="$line"
                    ;;
                9)
                    channel_camera_nvr="$line"
                    ;;
                10)
                    channel_extra_camera_nvr="$line"
                    ;;
                11)
                    audio_camera_nvr="$line"
                    ;;
                12)
                    brand_camera="$line"
                    ;;
                13)
                    idx_camera="$line"
                    ;;
                *);;
            esac
        fi
    done <<< "$(echo -e "$CAMERAS_NVR")"
}