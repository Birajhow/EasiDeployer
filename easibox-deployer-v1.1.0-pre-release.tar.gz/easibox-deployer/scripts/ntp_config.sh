function configureNTP() {
    printfInfo "Configuring NTP"

    if [ ! -f "$FILE_NTP_CFG.bak" ]; then
        sudo cp "$FILE_NTP_CFG" "$FILE_NTP_CFG.bak"
    else
        sudo cp "$FILE_NTP_CFG.bak" "$FILE_NTP_CFG"
    fi

    local new_ntp_servers="
    server ntp.easi.live
    server a.ntp.br
    server b.ntp.br
    server c.ntp.br
    server 0.br.pool.ntp.org
    server 1.br.pool.ntp.org
    server 2.br.pool.ntp.org
    server 3.br.pool.ntp.org"

    replaceStringInFile "$FILE_NTP_CFG" 'pool 0.ubuntu.pool.ntp.org iburst' '#pool 0.ubuntu.pool.ntp.org iburst'
    replaceStringInFile "$FILE_NTP_CFG" 'pool 1.ubuntu.pool.ntp.org iburst' '#pool 1.ubuntu.pool.ntp.org iburst'
    replaceStringInFile "$FILE_NTP_CFG" 'pool 2.ubuntu.pool.ntp.org iburst' '#pool 2.ubuntu.pool.ntp.org iburst'
    replaceStringInFile "$FILE_NTP_CFG" 'pool 3.ubuntu.pool.ntp.org iburst' '#pool 3.ubuntu.pool.ntp.org iburst'

    addStringToFile "$FILE_NTP_CFG" '#pool 3.ubuntu.pool.ntp.org' "$new_ntp_servers"

    replaceStringInFile "$FILE_NTP_CFG" 'restrict -4 default kod notrap nomodify nopeer noquery limited' 'restrict -4 default kod notrap nomodify nopeer noquery'
    replaceStringInFile "$FILE_NTP_CFG" 'restrict -6 default kod notrap nomodify nopeer noquery limited' 'restrict -4 default kod notrap nomodify nopeer noquery'
}
