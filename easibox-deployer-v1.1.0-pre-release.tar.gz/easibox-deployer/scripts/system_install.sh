function installGeneralTools() {
    printfInfo "Installing general tools"
    installApt "ffmpeg" "git" "cmake" "libtool" "autoconf" "automake" "openssh-server" "meson" "make" "unzip" "mlocate" "openvpn" "jq" "python3-pip"
}

function createBaseDirs() {
    printfInfo "Creating base directories"

    createDirSudo "$DIR_EASIBOX_BASE"
    if [ -d "$DIR_EASIBOX_BASE" ]; then
        sudo chown $USER_CURRENT:$USER_CURRENT "$DIR_EASIBOX_BASE"
    fi
    createDirSudo "$DIR_CA"
    createDirSudo "$DIR_KEY_CERT"
}

function disableNetworkCloudCfg() {
    printfInfo "Disabling cloud network auto config"

    sudo truncate -s0 "$FILE_CLOUD_CFG"
    echo "network: {config: disable}" | sudo tee -a "$FILE_CLOUD_CFG" &>> /dev/null
    sudo sync
}
