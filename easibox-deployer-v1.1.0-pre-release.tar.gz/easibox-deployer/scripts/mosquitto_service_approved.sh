function executeMosquittoService() {
    printfInfo "Restarting Mosquitto service"
    runService "snap.mosquitto.mosquitto"
}