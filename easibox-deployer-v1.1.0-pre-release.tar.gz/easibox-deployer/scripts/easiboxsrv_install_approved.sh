function installZeep() {
    if [ -f ~/python-zeep/dist/zeep-4.1.0-py2.py3-none-any.whl ] && [ $FORCE_REINSTALL_CUSTOM_DEPENDENCIES -eq 0 ]; then
        printfInfo "Installing zeep"
        printfDebug "Already installed zeep"
    else
        printfInfo "Installing zeep dependencies"
        installApt "python3-lxml"
        printfInfo "Installing base zeep"
        sudo pip3 install zeep &>>"$FILE_LOG";
        printfDebug "Installed base zeep"

        printfInfo "Cloning zeep"
        cd ~
        gitClone $GIT_EASIBOX_ZEEP
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "python-zeep"

        printfInfo "Installing zeep"
        python3 setup.py bdist_wheel &>>"$FILE_LOG";
        pip3 install ./ &>>"$FILE_LOG";
        printfDebug "Finished installing zeep"

        cd ..
        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r ./python-zeep &>>"$FILE_LOG";
        fi
    fi
}

function installEASiBox() {
    if [ $PRODUCTION_MODE -eq 1 ]; then
        if [ -d "$DIR_EASIBOX_BASE/easiboxsrv/.git" ]; then
            printfInfo "Removing EASiBox Server dev installation"
            sudo rm -r "$DIR_EASIBOX_BASE/easiboxsrv"
        fi

        printfInfo "Downloading and extracting EASiBox Server"
        local easibox_dir="$DIR_EASIBOX_BASE/easiboxsrv"
        download "easibox_dist_dev.zip" "$easibox_dir" $URL_EASIBOX_PRODUCTION --EXTRACT --OVERRIDE
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "$easibox_dir"

        sudo chmod +x "easiboxsrv" &>>"$FILE_LOG";
    else
        if [ "$TOKEN_GITHUB" == "" ]; then
            printfWarning "No GitHub token set, skipping easiboxsrv installation"
            return
        fi

        if [ -f "$DIR_EASIBOX_BASE/easiboxsrv/easiboxsrv" ]; then
            printfInfo "Removing EASiBox Server production installation"
            sudo rm -r "$DIR_EASIBOX_BASE/easiboxsrv"
        fi

        printfInfo "Cloning easiboxsrv"
        cd "$DIR_EASIBOX_BASE"
        gitClone $GIT_EASIBOX_DEV
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "easiboxsrv"
        git checkout easi-cash &>>"$FILE_LOG";
    fi

    printfInfo "Installing easiboxsrv requirements"
    sudo pip3 install -r "$DIR_EASIBOX_BASE/easiboxsrv/requirements.txt" &>>"$FILE_LOG";
}