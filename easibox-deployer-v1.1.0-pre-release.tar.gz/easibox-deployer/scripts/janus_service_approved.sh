function executeJanusService() {
    printfInfo "Starting Janus service"

    commandExists "janus"
    if [ "$?" -eq 1 ]; then
        local content_service_janus="
[Unit]
Description=Janus Service
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
Restart=always
RestartSec=1
User=$USER_CURRENT
ExecStart=/usr/bin/janus

[Install]
WantedBy=multi-user.target
        "

        runService "janus" "janus.service" "$content_service_janus"
    else
        printfError "Failed to start janus"
    fi
}