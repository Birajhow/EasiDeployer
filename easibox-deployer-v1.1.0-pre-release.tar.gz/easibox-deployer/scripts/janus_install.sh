function installLibSrtp() {
    if [ -f "/usr/lib/libsrtp2.so" ] && [ $FORCE_REINSTALL_CUSTOM_DEPENDENCIES -eq 0 ]; then
        printfInfo "Compiling and installing libsrtp"
        printfDebug "Already compiled and installed libsrtp"
    else
        local libsrtp_dir="/home/$USER_CURRENT/libsrtp-2.2.0"
        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
            printfInfo "Downloading and extracting precompiled libsrtp"
            download "v2.2.0.tar.zip" "$libsrtp_dir" $URL_JANUS_LIBSRTP_PRECOMPILED --EXTRACT
        else
            printfInfo "Downloading and extracting libsrtp"
            download "v2.2.0.tar.gz" "$libsrtp_dir" $URL_JANUS_LIBSRTP --EXTRACT
        fi
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "$libsrtp_dir"

        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 0 ]; then
            printfInfo "Compiling libsrtp"
            ./configure --prefix=/usr --enable-openssl &>>"$FILE_LOG";
            make shared_library &>>"$FILE_LOG";
            printfDebug "Finished compiling libsrtp"
        fi

        printfInfo "Installing libsrtp"
        sudo make install &>>"$FILE_LOG";
        printfDebug "Finished installing libsrtp"

        cd ..
        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r "$libsrtp_dir" &>>"$FILE_LOG";
        fi
    fi
}

function installLibNice() {
    commandExists "stund"
    if [ "$?" -eq 1 ]  && [ $FORCE_REINSTALL_CUSTOM_DEPENDENCIES -eq 0 ]; then
        printfInfo "Compiling and installing libnice"
        printfDebug "Already compiled and installed libnice"
    else
        printfInfo "Installing libnice dependencies"
        installApt "libglib2.0-dev" "libgnutls28-dev"

        local libnice_dir="/home/$USER_CURRENT/libnice"
        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
            printfInfo "Downloading and extracting precompiled libnice"
            download "libnice.zip" "$libnice_dir" $URL_JANUS_LIBNICE_PRECOMPILED --EXTRACT
            if [ "$?" -eq 0 ]; then
                printfError "Skipping step"
                return
            fi
            cd "$libnice_dir"
        else
            printfInfo "Cloning libnice"
            cd ~
            gitClone $GIT_JANUS_LIBNICE
            if [ "$?" -eq 0 ]; then
                printfError "Skipping step"
                return
            fi
            cd "$libnice_dir"
            git checkout 0.1.19 &>>"$FILE_LOG";
        fi

        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 0 ]; then
            printfInfo "Compiling libnice"
            meson --prefix=/usr build &>>"$FILE_LOG";
            ninja -C build &>>"$FILE_LOG";
            printfDebug "Finished compiling libnice"
        fi

        printfInfo "Installing libnice"
        sudo ninja -C build install &>>"$FILE_LOG";
        printfDebug "Finished installing libnice"

        cd ..
        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r ./libnice &>>"$FILE_LOG";
        fi
    fi
}

function installCurl() {
    if curl --version | grep -q "7.64.0"  && [ $FORCE_REINSTALL_CUSTOM_DEPENDENCIES -eq 0 ]; then
        printfInfo "Compiling and installing curl"
        printfDebug "Already compiled and installed curl"
    else
        printfInfo "Installing curl dependencies"
        installApt "libssl-dev"

        local curl_dir="/usr/local/src/curl-7.64.0"
        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
            printfInfo "Downloading and extracting precompiled curl"
            download "curl-7.64.0.zip" "$curl_dir" $URL_JANUS_CURL_PRECOMPILED --ROOT --EXTRACT
        else
            printfInfo "Downloading and extracting curl"
            download "curl-7.64.0.zip" "$curl_dir" $URL_JANUS_CURL --ROOT --EXTRACT
        fi
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "$curl_dir"

        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 0 ]; then
            printfInfo "Compiling curl"
            sudo ./buildconf &>>"$FILE_LOG";
            sudo ./configure --with-ssl --enable-versioned-symbols &>>"$FILE_LOG";
            sudo make &>>"$FILE_LOG";
            printfDebug "Finished compiling curl"
        fi

        printfInfo "Installing curl"
        sudo make install &>>"$FILE_LOG";
        sudo ldconfig &>>"$FILE_LOG";
        sudo apt-mark hold curl libcurl4 &>>"$FILE_LOG";
        printfDebug "Finished installing curl"

        cd ..
        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r "$curl_dir" &>>"$FILE_LOG";
        fi
    fi
}

function installJanus() {
    commandExists "janus"
    if [ "$?" -eq 1 ]  && [ $FORCE_REINSTALL_CUSTOM_DEPENDENCIES -eq 0 ]; then
        printfInfo "Compiling and installing Janus"
        printfDebug "Already compiled and installed janus"
    else
        printfInfo "Installing Janus dependencies"
        installApt "libmicrohttpd-dev" "libsofia-sip-ua-dev" "libglib2.0-dev" "libopus-dev" "libogg-dev" "libcurl4-openssl-dev" "liblua5.3-dev" "pkg-config" "libcurl4-openssl-dev"

        local janus_dir="/home/$USER_CURRENT/janus-gateway-1.0.3"
        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
            printfInfo "Downloading and extracting precompiled janus"
            download "v1.0.3.zip" "$janus_dir" $URL_JANUS_PRECOMPILED --EXTRACT
        else
            printfInfo "Downloading and extracting janus"
            download "v1.0.3.zip" "$janus_dir" $URL_JANUS --EXTRACT
        fi
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "$janus_dir"

        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 0 ]; then
            printfInfo "Compiling janus"
            sh autogen.sh &>>"$FILE_LOG";
            ./configure --exec-prefix=/usr --prefix= &>>"$FILE_LOG";
            sudo git config --global --add safe.directory /home/$USER_CURRENT/janus-gateway-1.0.3 &>>"$FILE_LOG";
            make &>>"$FILE_LOG";
            printfDebug "Finished compiling janus"
        fi

        printfInfo "Installing janus"
        sudo make install &>>"$FILE_LOG";
        printfDebug "Finished installing janus"

        cd ..
        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r "$janus_dir" &>>"$FILE_LOG";
        fi
    fi
}