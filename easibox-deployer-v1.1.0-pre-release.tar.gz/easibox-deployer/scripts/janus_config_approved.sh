function configureJanusStreaming() {
    printfInfo "Configuring Janus streaming plugin"
    if [ -f "$FILE_JANUS_PLUGIN_STREAMING" ]; then
        sudo rm "$FILE_JANUS_PLUGIN_STREAMING"
    fi

    echo "
general: {
        rtp_port_range = \"20000-30000\" # Range of ports to use for RTP/RTCP when '0' is
                                                            # passed as port for a mountpoint (default=10000-60000)
        string_ids = true
}
dvr: {
        type = \"rtp\"
        id = \"dvr\"
        audio = false
        video = true
        videoport = 5004
        videopt = 126
        videortpmap = \"H264/90000\"
        videofmtp = \"profile-level-id=42e01f;packetization-mode=1\"
}" | sudo tee -a "$FILE_JANUS_PLUGIN_STREAMING" &>> /dev/null

    local pos
    local host_nvr
    local user_nvr
    local password_nvr
    local port_rtsp_nvr
    local channel_camera_nvr
    local channel_extra_camera_nvr
    local audio_camera_nvr

    local camera_line_counter=0

    while read line; do
        if [ "$line" = "===" ]; then
            echo "live_$pos: {
    type = \"rtsp\"
    id = \"pos_$pos\"
    audio = $audio_camera_nvr
    video = true
    url = \"rtsp://$host_nvr:$port_rtsp_nvr/Streaming/channels/${channel_camera_nvr}${channel_extra_camera_nvr}\"
    rtsp_user = \"$user_nvr\"
    rtsp_pwd = \"$password_nvr\"
    rtsp_reconnect_delay = 5
    rtsp_session_timeout = 0
    rtsp_timeout = 10
    rtsp_conn_timeout = 5
    rtsp_failcheck = false
}" | sudo tee -a "$FILE_JANUS_PLUGIN_STREAMING" &>> /dev/null
            camera_line_counter=0

            pos=""
            host_nvr=""
            user_nvr=""
            password_nvr=""
            port_rtsp_nvr=""
            channel_camera_nvr=""
            channel_extra_camera_nvr=""
            audio_camera_nvr=""
        else
            camera_line_counter=$((camera_line_counter + 1))
            case $camera_line_counter in
                1)
                    pos="$line"
                    ;;
                2)
                    host_nvr="$line"
                    ;;
                3)
                    ;;
                4)
                    ;;
                5)
                    user_nvr="$line"
                    ;;
                6)
                    password_nvr="$line"
                    ;;
                7)
                    port_rtsp_nvr="$line"
                    ;;
                8)
                    ;;
                9)
                    channel_camera_nvr="$line"
                    ;;
                10)
                    channel_extra_camera_nvr="$line"
                    ;;
                11)
                    audio_camera_nvr="$line"
                    if [ $audio_camera_nvr -eq 0 ]; then
                        audio_camera_nvr='false'
                    else
                        audio_camera_nvr='true'
                    fi
                    ;;
                12)
                    ;;
                13)
                    ;;
                *);;
            esac
        fi
    done <<< "$(echo -e "$CAMERAS_NVR")"
}

function configureJanusMQTT() {
    printfInfo "Configuring Janus MQTT transport"
    sudo cp "$FILE_JANUS_TRANSPORT_SAMPLE_MQTT" "$FILE_JANUS_TRANSPORT_MQTT"
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '\tenabled = false\t' '\tenabled = true\t'
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" 'url = "tcp://localhost:1883"' "url = \"ssl://127.0.0.1:$PORT_MQTT\""
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '#keep_alive_interval' 'keep_alive_interval'
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '#cleansession = 0' 'cleansession = 1'
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '#client_id = "guest"' "client_id = \"JANUS_$MAC_FORMATTED_UPPERCASE\""
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" 'subscribe_topic = "to-janus"' "subscribe_topic = \"v1/store/$IDX_STORE/device_idx/$IDX_EASIBOX/janus/to\""
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '#subscribe_qos = 1' 'subscribe_qos = 2'
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" 'publish_topic = "from-janus"' "publish_topic = \"v1/store/$IDX_STORE/device_idx/$IDX_EASIBOX/janus/from\""
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '#publish_qos = 1' 'publish_qos = 2'
    replaceStringInFile "$FILE_JANUS_TRANSPORT_MQTT" '#ssl_enabled' 'ssl_enabled'

    local certs="
        cacertfile = \"$FILE_CA\"
        certfile = \"$FILE_CERT\"
        keyfile = \"$FILE_KEY\"
    "

    addStringToFile "$FILE_JANUS_TRANSPORT_MQTT" "#keyfile = " "$certs"
}