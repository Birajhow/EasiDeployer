function validateNetworkInterface() {
    # Only set a dynamic IP with a set interface
    if [ "$IP_INTERNAL_STATIC" = "" ] && [ "$NETWORK_INTERFACE" = "" ]; then
        printfInfo "Unable to detect an active network interface. Possible options:"
        printfInfo "$(showPhysicalNetworkInterfaceNames)"
        echo
        read -p "Type one to proceed: " NETWORK_INTERFACE </dev/tty
        echo
        if [ "$NETWORK_INTERFACE" = "" ]; then
            printfCritical "Empty network interface not allowed"
            read -p ""
            exit
        fi
    fi
}

function setIPAddress() {
    local renderer=""

    if [ "$NETWORK_RENDERER" != "" ]; then
        renderer="\nrenderer: $NETWORK_RENDERER\n"
    fi

    if [ "$IP_INTERNAL_STATIC" = "" ]; then
        printfInfo "Setting dynamic IP"
    else
        printfInfo "Setting static IP: $IP_INTERNAL_STATIC"
    fi

    if [ "$NETWORK_INTERFACE" = "" ] && [ "$NETWORK_INTERFACE_CUSTOM" = "" ]; then
        printfError "Failed to set IP: Missing network interface name! Configure one manually or connect the EASiBox to the internet before applying the settings, otherwise this installation will not work."
    else
        isInternalIPDynamic
        local is_internal_ip_dynamic=$?
        local nameservers="$(cat "$FILE_NETPLAN" | grep "addresses: \[")"
        local dns1_active=1 # This must exist
        local dns2_active=0
        if echo "$nameservers" | grep -q ','; then
            dns2_active=1
        fi

        if [ "$IP_INTERNAL_STATIC" = "" ] && [ $is_internal_ip_dynamic -eq 1 ]; then
            printfDebug "The current IP is already dynamic"
        else
            if [ "$IP_INTERNAL_STATIC" != "" ] && [ $is_internal_ip_dynamic -eq 0 ]; then
                if cat "$FILE_NETPLAN" | grep -q "$NETWORK_INTERFACE_CUSTOM" &&
                cat "$FILE_NETPLAN" | grep -q "$GATEWAY_CUSTOM" &&
                cat "$FILE_NETPLAN" | grep -q "$IP_INTERNAL_STATIC" &&
                ( [ "$NAMESERVER_PRIMARY_CUSTOM" = "" ] && [ $dns1_active -eq 0 ] || [ "$NAMESERVER_PRIMARY_CUSTOM" != "" ] && cat "$FILE_NETPLAN" | grep -q "$NAMESERVER_PRIMARY_CUSTOM" ) &&
                ( [ "$NAMESERVER_SECONDARY_CUSTOM" = "" ] && [ $dns2_active -eq 0 ] || [ "$NAMESERVER_SECONDARY_CUSTOM" != "" ] && cat "$FILE_NETPLAN" | grep -q "$NAMESERVER_SECONDARY_CUSTOM" ) &&
                cat "$FILE_NETPLAN" | grep -q "$SUBMASK_CUSTOM"; then
                    printfDebug "Skipping identical static IP configuration"
                    return
                fi
            fi

            local netplan_config=""
            if [ "$IP_INTERNAL_STATIC" = "" ]; then
                netplan_config+="
network:
  version: 2 $renderer
  ethernets:
    $NETWORK_INTERFACE:
      dhcp4: yes"
            else
                local nameservers

                if [ "$NAMESERVER_PRIMARY_CUSTOM" = "" ]; then
                    printfError "Failed to set static IP, a primary DNS must be provided"
                    return
                elif [ "$NAMESERVER_SECONDARY_CUSTOM" = "" ]; then
                    nameservers="[$NAMESERVER_PRIMARY_CUSTOM]"
                else
                    nameservers="[$NAMESERVER_PRIMARY_CUSTOM, $NAMESERVER_SECONDARY_CUSTOM]"
                fi

                netplan_config+="
network:
  version: 2 $renderer
  ethernets:
    $NETWORK_INTERFACE_CUSTOM:
      dhcp4: no
      addresses:
        - $IP_INTERNAL_STATIC/$SUBMASK_CUSTOM
      gateway4: $GATEWAY_CUSTOM
      nameservers:
        addresses: $nameservers"
            fi

            sudo truncate -s0 "$FILE_NETPLAN"
            echo "${netplan_config}" | sudo tee -a "$FILE_NETPLAN" &>> /dev/null

            sudo netplan apply &>> /dev/null
            if [ "$?" -eq 0 ]; then
                if [ "$IP_INTERNAL_STATIC" = "" ]; then
                    printfDebug "Setted dynamic IP"
                else
                    printfDebug "Setted static IP"
                fi
            else
                if [ "$IP_INTERNAL_STATIC" = "" ]; then
                    printfError "Failed to set dynamic IP"
                else
                    printfError "Failed to set static IP"
                fi
            fi
        fi
    fi
}