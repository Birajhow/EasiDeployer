function installMQTT() {
    commandExists "MQTTVersion"
    if [ "$?" -eq 1 ]  && [ $FORCE_REINSTALL_CUSTOM_DEPENDENCIES -eq 0 ]; then
        printfInfo "Compiling and installing MQTT"
        printfDebug "Already compiled and installed MQTT"
    else
        printfInfo "Installing MQTT dependencies"
        installApt "libssl-dev" "libwebsockets-dev" "libjansson-dev" "libconfig-dev" "gengetopt"

        local mqtt_dir="/home/$USER_CURRENT/paho.mqtt.c"
        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
            printfInfo "Downloading and extracting precompiled MQTT"
            download "paho.mqtt.c.zip" "$mqtt_dir" $URL_MQTT_PRECOMPILED --EXTRACT
            if [ "$?" -eq 0 ]; then
                printfError "Skipping step"
                return
            fi
            cd "$mqtt_dir"
        else
            printfInfo "Cloning MQTT"
            cd ~
            gitClone $GIT_MQTT
            if [ "$?" -eq 0 ]; then
                printfError "Skipping step"
                return
            fi
            cd "$mqtt_dir"
            sudo git config --global --add safe.directory "$mqtt_dir" &>>"$FILE_LOG";
            sudo git checkout v1.3.9 &>>"$FILE_LOG";
        fi

        if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 0 ]; then
            printfInfo "Compiling MQTT"
            cmake . -DCMAKE_INSTALL_PREFIX:PATH=/usr -DPAHO_WITH_SSL=True &>>"$FILE_LOG";
            make &>>"$FILE_LOG";
            printfDebug "Finished compiling MQTT"
        fi

        printfInfo "Installing MQTT"
        sudo make install &>>"$FILE_LOG";
        printfDebug "Finished installing MQTT"

        cd ..
        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r "$mqtt_dir" &>>"$FILE_LOG";
        fi
    fi
}