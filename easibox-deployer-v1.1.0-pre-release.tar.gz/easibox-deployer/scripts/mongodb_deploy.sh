function deployMongoDB() {
    printfInfo "Deploying MongoDB"
    sudo docker stack deploy -c "$FILE_MONGO_COMPOSE" mongo &>>"$FILE_LOG";

    local is_deployed=0

    sleep 1

    local count_deploy=7
    for i in `seq $count_deploy`; do
        count_deploy=$((count_deploy - 1))

        if sudo docker stack ls | grep -q 'mongo'; then
            if sudo docker stack ps mongo | grep -q -E 'Pending|Preparing|Assigned|Starting|Running'; then
                printfDebug "Deployed MongoDB"
                is_deployed=1
                break
            else
                printfDebug "The deployment is not ready... ($count_deploy checks remaining)"
            fi
        else
            printfDebug "The deployment is not ready... ($count_deploy checks remaining)"
        fi

        sleep 3
    done

    if [ $is_deployed -eq 0 ]; then
        printfError "Failed to deploy MongoDB"
    fi

    rm "$FILE_MONGO_COMPOSE" &>>"$FILE_LOG";
}

function initializeMongoDB() {
    printfInfo "Initializating MongoDB"

    local is_deployed=0

    local count_deploy=7
    for i in `seq $count_deploy`; do
        count_deploy=$((count_deploy - 1))

        if sudo docker stack ls | grep -q 'mongo'; then
            if sudo docker stack ps mongo | grep -q -E 'Pending|Preparing|Assigned|Starting|Running'; then
                printfDebug "MongoDB is deployed"
                is_deployed=1
                break
            else
                printfDebug "The deployment is not ready... ($count_deploy checks remaining)"
            fi
        else
            printfDebug "The deployment is not ready... ($count_deploy checks remaining)"
        fi

        sleep 3
    done

    if [ $is_deployed -eq 0 ]; then
        printfError "MongoDB is not deployed"
    else
        local has_container=0
        local count_init=10
        for i in `seq $count_init`; do
            if sudo docker stack ps mongo | grep -q 'Running'; then
                local container_id="$(sudo docker ps -qf "name=mongo_mongo")"

                count_init=$((count_init - 1))

                if [ "$container_id" != "" ]; then
                    if sudo docker container ls | grep "$container_id" | grep -q ' Up '; then
                        has_container=1

                        local commands='
                            use server2
                            db.createCollection("eventsPOS")
                            db.eventsPOS.createIndexes([{ "$**": 1}])
                            exit
                        '

                        local res="$(echo "${commands}" | sudo docker exec -i $container_id mongo)"

                        if echo $res | grep -q 'switched to db server2'; then
                            printfDebug "Initialized MongoDB database"
                        else
                            printfError "Failed to initialize MongoDB database"
                        fi

                        break
                    else
                        printfDebug "The container is not ready... ($count_init checks remaining)"
                    fi
                else
                    printfDebug "The container is not ready... ($count_init checks remaining)"
                fi
            else
                printfDebug "The container is not ready... ($count_init checks remaining)"
            fi

            sleep 15
        done

        if [ $has_container -eq 0 ]; then
            printfError "Failed to get MongoDB container"
        fi
    fi
}