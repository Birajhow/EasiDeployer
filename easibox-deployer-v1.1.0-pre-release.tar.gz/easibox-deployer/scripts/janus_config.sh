function configureJanus() {
    printfInfo "Configuring Janus"
    sudo cp "$FILE_JANUS_SAMPLE_CFG" "$FILE_JANUS_CFG"
    replaceStringInFile "$FILE_JANUS_CFG" '#disable = "libjanus_voicemail.so,libjanus_recordplay.so"' 'disable = "libjanus_voicemail.so, libjanus_videocall.so, libjanus_videoroom.so, libjanus_recordplay.so, libjanus_nosip.so, libjanus_sip.so, libjanus_echotest.so, libjanus_audiobridge.so"'
    replaceStringInFile "$FILE_JANUS_CFG" '#disable = "libjanus_rabbitmq.so"' 'disable = "libjanus_rabbitmq.so, libjanus_nanomsg.so, libjanus_pfunix.so, libjanus_websockets.so"'
    replaceStringInFile "$FILE_JANUS_CFG" '#stun_server = "stun.voip.eutelia.it"' 'stun_server = "stun.easi.live"'
    replaceStringInFile "$FILE_JANUS_CFG" '#stun_port = 3478' 'stun_port = 3478'
    replaceStringInFile "$FILE_JANUS_CFG" '#full_trickle = true' 'full_trickle = true'
    replaceStringInFile "$FILE_JANUS_CFG" 'ice_ignore_list = "vmnet"' 'ice_ignore_list = "vmnet,10.8."'

    printfInfo "Configuring Janus HTTP transport"
    sudo cp "$FILE_JANUS_TRANSPORT_SAMPLE_HTTP" "$FILE_JANUS_TRANSPORT_HTTP"
}