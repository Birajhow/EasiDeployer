function addMySQLUser() {
    printfInfo "Adding MySQL user"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running, skipping step"
        return
    fi

    if [ $(echo "SELECT COUNT(*) FROM mysql.user WHERE user = '$USER_MYSQL'" | sudo mysql | tail -n1) -eq 0 ]; then
        sudo mysql --execute="
            CREATE USER '$USER_MYSQL'@'%' IDENTIFIED BY '$PASSWORD_MYSQL';
            CREATE USER '$USER_MYSQL'@'localhost' IDENTIFIED BY '$PASSWORD_MYSQL';
            GRANT ALL PRIVILEGES ON $DATABASE_MYSQL.* TO '$USER_MYSQL'@'%';
        " &>>"$FILE_LOG";
        printfDebug "MySQL user created"
    else
        printfDebug "Already created MySQL user"
    fi
}

function configureMySQL() {
    printfInfo "Configuring MySQL"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running, skipping step"
        return
    fi

    local mysql_package_exists=$(apt-cache search --names-only '^mysql-server$')
    local conf_file
    if [ "$mysql_package_exists" != "" ]; then
        conf_file="$FILE_MYSQL_CNF"
    else
        conf_file="$FILE_MARIADB_CNF"
    fi
    replaceStringInFile "$conf_file" 'bind-address		= 127.0.0.1' 'bind-address		= 0.0.0.0'
}