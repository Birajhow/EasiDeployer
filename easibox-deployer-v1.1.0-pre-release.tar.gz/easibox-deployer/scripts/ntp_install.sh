function installNTP() {
    printfInfo "Installing NTP"
    installApt "ntp"
}

function disableNTPDHCPOverride() {
    printfInfo "Disabling NTP DHCP overriding"

    if [ ! -f "$FILE_NTP_DHCP.bak" ]; then
        sudo cp "$FILE_NTP_DHCP" "$FILE_NTP_DHCP.bak"
    else
        sudo cp "$FILE_NTP_DHCP.bak" "$FILE_NTP_DHCP"
    fi

    addStringToFile "$FILE_NTP_DHCP" 'ntp_servers_setup\(\)' '        return'
}
