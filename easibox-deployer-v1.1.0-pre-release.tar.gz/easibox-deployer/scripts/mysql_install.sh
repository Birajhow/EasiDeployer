function installMySQL() {
    local mysql_package_exists=$(apt-cache search --names-only '^mysql-server$')
    if [ "$mysql_package_exists" != "" ]; then
        printfInfo "Installing MySQL"
        installApt "mysql-server"
    else
        printfInfo "Installing MariaDB"
        installApt "mariadb-server"
    fi
}