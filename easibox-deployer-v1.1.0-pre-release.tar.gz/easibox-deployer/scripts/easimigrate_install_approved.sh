function installEASiBoxMigrate() {
    local easiboxmigrate_dir="/home/$USER_CURRENT/easiboxmigrate"
    if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
        printfInfo "Downloading and extracting precompiled easiboxmigrate"
        download "easiboxmigrate.zip" "$easiboxmigrate_dir" $URL_EASIBOX_MIGRATE --EXTRACT
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "$easiboxmigrate_dir"
    else
        if [ "$TOKEN_GITHUB" == "" ]; then
            printfWarning "No GitHub token set, skipping easiboxmigrate installation"
            return
        fi

        printfInfo "Cloning easiboxmigrate"
        cd "/home/$USER_CURRENT"
        gitClone $GIT_EASIBOX_MIGRATE
        if [ "$?" -eq 0 ]; then
            printfError "Skipping step"
            return
        fi
        cd "$easiboxmigrate_dir"

        printfInfo "Installing easiboxmigrate requirements"
        sudo pip3 install -r "requirements.txt" &>>"$FILE_LOG";
    fi
}

function applyMigrations() {
    printfInfo "Applying migrations"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not running. Skipping step"
        return
    fi

    local db_res
    local easiboxmigrate_dir="/home/$USER_CURRENT/easiboxmigrate"

    local mysql_package_exists=$(apt-cache search --names-only '^mysql-server$')
    if [ "$mysql_package_exists" = "" ]; then
        printfWarning "Making migrations compatible with MariaDB"
        sed -i 's/VISIBLE//g' migrations/* &>>"$FILE_LOG";
        sed -i 's/utf8mb4_0900_ai_ci/utf8mb4_general_ci/g' migrations/* &>>"$FILE_LOG";
    fi

    if [ $DOWNLOAD_PRECOMPILED_DEPENDENCIES -eq 1 ]; then
        db_res=$(./migrate up -y)
    else
        db_res=$(python3 migrate.py up -y)
    fi

    if echo $db_res | grep -q "Error"; then
        printfError "Failed to apply migrations"
    else
        printfDebug "Finished applying migrations"
        cd ..

        if [ "$PRODUCTION_MODE" -eq 1 ]; then
            sudo rm -r "$easiboxmigrate_dir" &>>"$FILE_LOG";
        fi
    fi
    echo $db_res &>>"$FILE_LOG";
}