function installMosquitto() {
    printfInfo "Installing Mosquitto"
    installSnap "mosquitto"
}