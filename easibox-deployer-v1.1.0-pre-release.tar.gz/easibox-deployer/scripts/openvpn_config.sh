function configureOpenVPN() {
    isStringEmpty "$CONTENT_OPEN_VPN"
    if [ "$?" -eq 1 ]; then
        printfWarning "Missing OpenVPN configuration. Skipping script"
        return
    fi

    printfInfo "Configuring OpenVPN"
    sudo truncate -s0 "$FILE_OPEN_VPN_ROOT_CFG"
    echo "${CONTENT_OPEN_VPN}" | sudo tee -a "$FILE_OPEN_VPN_ROOT_CFG" &>> /dev/null
    replaceStringInFile "$FILE_OPEN_VPN_DEFAULT_CFG" '#AUTOSTART="all"' 'AUTOSTART="all"'
}