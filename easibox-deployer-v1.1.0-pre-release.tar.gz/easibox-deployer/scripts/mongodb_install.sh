function installMongoDB() {
    printfInfo "Installing MongoDB dependencies"
    installApt "ca-certificates" "gnupg" "lsb-release"

    printfInfo "Setting MongoDB repository"
    createDirSudo "/etc/apt/keyrings"
    if [ ! -f "/etc/apt/keyrings/docker.gpg" ]; then
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o "/etc/apt/keyrings/docker.gpg"
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $DISTRIB_CODENAME stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    fi

    printfInfo "Updating repositories"
    sudo apt-get update &>>"$FILE_LOG";

    printfInfo "Installing Docker"
    installApt "docker-ce" "docker-ce-cli" "containerd.io" "docker-compose-plugin"
    sudo docker swarm init &>>"$FILE_LOG";

    printfInfo "Creating directories"
    createDirSudo "$DIR_MONGO_DATA_LOGS"
    sudo chown -R $USER_CURRENT:$USER_CURRENT "$DIR_MONGO_DATA_LOGS"
    createDirSudo "$DIR_MONGO_DATA_DB"
    sudo chown -R $USER_CURRENT:$USER_CURRENT "$DIR_MONGO_DATA_DB"
    sudo chmod 755 -R "$DIR_MONGO_DATA"
}