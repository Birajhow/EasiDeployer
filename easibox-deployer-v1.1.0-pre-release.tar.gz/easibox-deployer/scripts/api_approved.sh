function getBoxToken() {
    printfInfo "Getting EASiBox token"

    isStringEmpty "$LICENSE_KEY"
    if [ "$?" -eq 1 ]; then
        printfWarning "No certificate key provided"
        printfWarning "Complete the certificates configuration in the main menu and apply the changes"
        return
    fi

    local response
    local message

    if [ -z "$TOKEN_EASIBOX" ]; then
        response=$(curl --silent -X POST -d "version=$VERSION_EASIBOX_TOKEN_API" -d "password=$LICENSE_KEY" -d "mac_address=$MAC_FORMATTED_LOWERCASE" "$ENDPOINT_EASIBOX/$ENDPOINT_EASIBOX_TOKEN")
        local token=$(echo $response | jq -r '.access_token')

        if [ "$token" == "null" ]; then
            printfError "Failed to get token. Skipping step"
            printfError "$response"
            return
        else
            printfDebug "Got token"
            TOKEN_EASIBOX=$token
        fi
    else
        printfDebug "Using predefined token"
    fi
}

function getBoxInfo() {
    printfInfo "Getting EASiBox info"

    isStringEmpty "$LICENSE_KEY"
    if [ "$?" -eq 1 ]; then
        printfWarning "No certificate key provided"
        printfWarning "Complete the certificates configuration in the main menu and apply the changes"
        return
    fi

    local response
    local message

    if [ -z "$IDX_EASIBOX" ] || [ -z "$IDX_STORE" ] || [ -z "$LIST_JANUS_CAMERAS" ]; then
        response=$(curl --silent -X POST -F "token=$TOKEN_EASIBOX" -F "mac_address=$MAC_FORMATTED_LOWERCASE" "$ENDPOINT_EASIBOX/$ENDPOINT_EASIBOX_GET_CASHBOX_INFO")
        message=$(echo $response | jq -r '.message')

        if [ "$message" != "null" ]; then
            if [ -z "$FACTORY_APPROVED_EASIBOX" ]; then
                printfError "Failed to get info. Skipping step $response"
            else
                printfWarning "This easibox is not registered in any store or doesn't have a proper license"
            fi
            return
        else
            if [ ! -z "$IDX_EASIBOX" ]; then
                printfDebug "Using predefined EASiBox idx"
            else
                local box_idx=$(echo $response | jq -r '.box_idx')

                if [ "$box_idx" == "null" ]; then
                    printfError "Failed to get EASiBox idx. Skipping step $response"
                    return
                else
                    printfDebug "EASiBox idx: $box_idx"
                    IDX_EASIBOX=$box_idx
                fi
            fi

            if [ ! -z "$IDX_STORE" ]; then
                printfDebug "Using predefined store idx"
            else
                local store_idx=$(echo $response | jq -r '.store_idx')

                if [ "$store_idx" == "null" ]; then
                    printfError "Failed to get store idx. Skipping step $response"
                    return
                else
                    printfDebug "Store idx: $store_idx"
                    IDX_STORE=$store_idx
                fi
            fi

            if [ ! -z "$POS_LIST_STORE" ]; then
                printfDebug "Using predefined POS list"
            else
                local pos_list_keys=$(echo $response | jq -r '.pos | keys[]' | tr ' ' '\n')

                if [ "$pos_list_keys" == "null" ]; then
                    printfWarning "No POS set."
                else
                    local first
                    while read line; do
                        if [ "$first" != "" ]; then
                            POS_LIST_STORE="$POS_LIST_STORE "
                        else
                            first=1
                        fi

                        if [ "$line" != "" ]; then
                            POS_LIST_STORE="$POS_LIST_STORE$line"
                        fi
                    done <<< "$(echo -e "$pos_list_keys")"
                fi
            fi

            if [ ! -z "$CAMERA_LIST_STORE" ]; then
                printfDebug "Using predefined cameras list"
            else
            local pos_list_values=$(echo $response | jq -r '.pos[]' | tr ' ' '\n')

                if [ "$pos_list_values" == "null" ]; then
                    printfWarning "No cameras set."
                else
                    first=
                    while read line; do
                        if [ "$first" != "" ]; then
                            CAMERA_LIST_STORE="$CAMERA_LIST_STORE "
                        else
                            first=1
                        fi

                        if [ "$line" != "" ]; then
                            CAMERA_LIST_STORE="$CAMERA_LIST_STORE$line"
                        fi
                    done <<< "$(echo -e "$pos_list_values")"
                fi
            fi

            pos_list_keys=(${POS_LIST_STORE// / })
            pos_list_values=(${CAMERA_LIST_STORE// / })

            printfDebug "POS - Camera idx:"
            for ((i = 0; i <= ${#pos_list_keys}; ++i )); do
                printfDebug "${pos_list_keys[$i]} - ${pos_list_values[$i]}"
            done
        fi
    else
        printfDebug "Using predefined info"
    fi
}
