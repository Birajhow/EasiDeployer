function executeNTPService() {
    printfInfo "Restarting NTP service"
    runService "ntp"
}