function executeMySQLService() {
    printfInfo "Restarting MySQL service"
    runService "mysql"
}