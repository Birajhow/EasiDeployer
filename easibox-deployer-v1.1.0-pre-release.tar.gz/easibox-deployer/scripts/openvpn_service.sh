function executeOpenVPNService() {
    isStringEmpty "$CONTENT_OPEN_VPN"
    if [ "$?" -eq 1 ]; then
        printfWarning "Missing OpenVPN configuration. Skipping script"
        return
    fi

    printfInfo "Starting OpenVPN service"
    runService "openvpn@ovpn"
}