function installCertificates() {
    printfInfo "Installing EASiBox certificates"

    function installCertificate() {
        local certificate="$1"
        local file="$2"

        isStringEmpty "$certificate"
        if [ $? -eq 1 ]; then
            printfError "Failed to install certificate. No data provided for: $file"
        else
            sudo truncate -s0 "$file"
            echo "${certificate}" | sudo tee -a "$file" &>> /dev/null
            printfDebug "Installed certificate: $file"
        fi
    }

    cd ~

    isStringEmpty "$CONTENT_KEY"
    local is_key_empty=$?
    isStringEmpty "$CONTENT_CA"
    local is_ca_empty=$?
    isStringEmpty "$CONTENT_CERT"
    local is_cert_empty=$?

    local is_key_valid=0

    local ca_and_cert_match=0
    local key_and_cert_match=0

    if [ $is_key_empty -eq 1 ]; then
        printfWarning 'No KEY certificate provided'
    else
        printfDebug 'KEY certificate provided'
        echo "$CONTENT_KEY" | tee -a 'temp.key' &>> /dev/null
    fi

    if [ $is_ca_empty -eq 1 ]; then
        printfWarning 'No CA certificate provided'
    else
        printfDebug 'CA certificate provided'
        echo "$CONTENT_CA" | tee -a 'temp.ca' &>> /dev/null
    fi

    if [ $is_cert_empty -eq 1 ]; then
        printfWarning 'No CERT certificate provided'
    else
        printfDebug 'CERT certificate provided'
        echo "$CONTENT_CERT" | tee -a 'temp.cert' &>> /dev/null
    fi

    if [ $is_key_empty -eq 0 ]; then
        if echo $(openssl rsa -in 'temp.key' -check -noout 2>> /dev/null) | grep -q 'RSA key ok'; then
            printfDebug 'The Key certificate is valid'
            is_key_valid=1
        else
            printfError 'The Key certificate is invalid'
        fi
    fi

    if [ $is_ca_empty -eq 0 ] && [ $is_cert_empty -eq 0 ]; then
        if echo $(openssl verify -verbose -CAfile 'temp.ca' 'temp.cert' 2>> /dev/null) | grep -q 'temp.cert: OK'; then
            printfDebug 'The CA and CERT certificates match'
            ca_and_cert_match=1
        else
            printfError "The CA and CERT certificates don't match"
        fi
    fi

    if [ $is_key_valid -eq 1 ] && [ $is_cert_empty -eq 0 ]; then
        local sha_cert=$(openssl x509 -in "temp.cert" -pubkey -noout -outform pem | sha256sum)
        local sha_key=$(openssl pkey -in 'temp.key' -pubout -outform pem | sha256sum)

        if [ "$sha_cert" == "$sha_key" ]; then
            printfDebug 'The KEY and CERT certificates match'
            key_and_cert_match=1
        else
            printfError "The KEY and CERT certificates don't match"
        fi
    fi

    if [ $is_key_empty -eq 1 ] || [ $is_ca_empty -eq 1 ] || [ $is_cert_empty -eq 1 ]; then
        printfWarning "Complete the certificates configuration in the main menu and apply the changes"
    elif [ $ca_and_cert_match -eq 0 ] || [ $key_and_cert_match -eq 0 ]; then
        printfError "The provided certificates won't be installed"
    else
        installCertificate "$CONTENT_KEY" "$FILE_KEY"
        installCertificate "$CONTENT_CA" "$FILE_CA"
        installCertificate "$CONTENT_CERT" "$FILE_CERT"
    fi

    if [ $is_key_empty -eq 0 ]; then
        rm 'temp.key'
    fi

    if [ $is_ca_empty -eq 0 ]; then
        rm 'temp.ca'
    fi

    if [ $is_cert_empty -eq 0 ]; then
        rm 'temp.cert'
    fi
}