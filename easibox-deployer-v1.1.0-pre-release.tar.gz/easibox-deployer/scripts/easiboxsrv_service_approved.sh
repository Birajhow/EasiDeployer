function executeEasiboxService() {
    printfInfo "Starting easiboxsrv service"

    local file_easibox
    local command_easibox

    if [ $PRODUCTION_MODE -eq 1 ]; then
        file_easibox="$DIR_EASIBOX_BASE/easiboxsrv/easiboxsrv"
        command_easibox="$file_easibox"
    else
        file_easibox="$DIR_EASIBOX_BASE/easiboxsrv/easiboxsrv.py"
        command_easibox="/usr/bin/python3 $file_easibox"
    fi

    if [ -f "$file_easibox" ]; then
        local content_service_easibox_cash="
[Unit]
Description=EASiBox Server Service
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
Restart=always
RestartSec=1
User=$USER_CURRENT
ExecStart=$command_easibox -s cash
WorkingDirectory=$DIR_EASIBOX_BASE/easiboxsrv

[Install]
WantedBy=multi-user.target
"

        runService "easiboxsrv" "easiboxsrv.service" "$content_service_easibox_cash"
    else
        printfError "Failed to start easiboxsrv"
    fi
}

function executeEasiboxmidService() {
    printfInfo "Starting easiboxsrvmid service"

    if [ "$BLOCK_EASIBOX_MID_RESTART" != "" ]; then
        printfWarning "Skipping easiboxsrvmid service restart"
        return
    fi

    local file_easibox
    local command_easibox

    if [ $PRODUCTION_MODE -eq 1 ]; then
        file_easibox="$DIR_EASIBOX_BASE/easiboxsrv/easiboxsrv"
        command_easibox="$file_easibox"
    else
        file_easibox="$DIR_EASIBOX_BASE/easiboxsrv/easiboxsrv.py"
        command_easibox="/usr/bin/python3 $file_easibox"
    fi

    if [ -f "$file_easibox" ]; then
        local content_service_easibox_mid="
[Unit]
Description=EASiBox Server Service Mid
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
Restart=always
RestartSec=1
User=$USER_CURRENT
ExecStart=$command_easibox -s middle
WorkingDirectory=$DIR_EASIBOX_BASE/easiboxsrv

[Install]
WantedBy=multi-user.target
"

        runService "easiboxsrvmid" "easiboxsrvmid.service" "$content_service_easibox_mid"
    else
        printfError "Failed to start easiboxsrvmid"
    fi
}
