apply_config_certificates="
installCertificates
configureMosquitto
linkMosquittoCertificates
"

function showCertificatesOptions() {
    while true; do    
        printSectionTitle "Certificates"

        local options=(
            "Show"
            "Change"
            "Apply"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showCertificatesConfig
                    break
                    ;;
                "${options[1]}")
                    configureCertificates
                    break
                    ;;
                "${options[2]}")
                    applyCertificatesConfigs
                    break
                    ;;
                "${options[3]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done

    return
}

function showCertificatesConfig() {
    printSectionTitle "Current certificates configuration:"

    printfInfo "CA certificate:"
    if [ "$CONTENT_CA" == "" ]; then
        printfWarning "None"
    else
        printfInfo "$CONTENT_CA"
    fi
    echo
    printfInfo "CERT certificate:"
    if [ "$CONTENT_CERT" == "" ]; then
        printfWarning "None"
    else
        printfInfo "$CONTENT_CERT"
    fi
    echo
    printfInfo "KEY certificate:"
    if [ "$CONTENT_KEY" == "" ]; then
        printfWarning "None"
    else
        printfInfo "$CONTENT_KEY"
    fi
    echo
    printfInfo "Remote KEY certificate:"
    if [ "$CONTENT_KEY" == "" ]; then
        printfWarning "None"
    else
        echo
        printfInfo "$(echo "${CONTENT_OPEN_VPN}" | sed -n '/BEGIN PRIVATE KEY-----/,/-----END PRIVATE/p')"
    fi

    finishOption
}

function setCertificate() {
    local target="$1"
    local cert_type="$2"
    local cert_var="$3"

    echo
    echo "EASiBox certificate - $cert_type: "
    printfInfo "Press any key to open the text editor, paste the certificate, save with Ctrl + S, close with Ctrl + X..."
    read -n 1 -s -r -p "" </dev/tty
    sudo nano "temp.cert"
    if [ -f "temp.cert" ]; then
        local cert_content=$(sudo cat "temp.cert")
        sudo rm "temp.cert"
        export "$cert_var=$cert_content"
        printfInfo "Data saved"
    else
        printfWarning "No data provided"
    fi
}

function configureCertificates() {
    printSectionTitle "Type the configurations:"

    printfInfo "Your MAC is: $MAC_FORMATTED_LOWERCASE"

    setCertificate "$FILE_CONFIG_CERTIFICATES" "CA" "CONTENT_CA"
    setCertificate "$FILE_CONFIG_CERTIFICATES" "Public" "CONTENT_CERT"
    setCertificate "$FILE_CONFIG_CERTIFICATES" "Private" "CONTENT_KEY"

    setCertificate "$FILE_CONFIG_CERTIFICATES" "Remote" "CONTENT_OPEN_VPN"

    cp "$FILE_CONFIG_CERTIFICATES_EXAMPLE" "$FILE_CONFIG_CERTIFICATES"

    addStringToFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_CA=\"\"" "CONTENT_CA=\"$CONTENT_CA\""
    replaceStringInFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_CA=\"\"" ''
    addStringToFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_CERT=\"\"" "CONTENT_CERT=\"$CONTENT_CERT\""
    replaceStringInFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_CERT=\"\"" ''
    addStringToFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_KEY=\"\"" "CONTENT_KEY=\"$CONTENT_KEY\""
    replaceStringInFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_KEY=\"\"" ''

    addStringToFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_OPEN_VPN=\"\"" "CONTENT_OPEN_VPN=\"$CONTENT_OPEN_VPN\""
    replaceStringInFile "$FILE_CONFIG_CERTIFICATES" "CONTENT_OPEN_VPN=\"\"" ''

    finishOption
}

function applyCertificatesConfigs() {
    printSectionTitle "Apllying current certificate configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    echo "$apply_config_certificates" | while IFS= read -r line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done

    sudo sync

    finishOption
}