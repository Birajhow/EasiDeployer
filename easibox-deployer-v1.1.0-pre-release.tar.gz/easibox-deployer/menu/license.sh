apply_config_license="
setLiceseDBKey
configureMosquitto
"

function showLicenseOptions() {
    while true; do    
        printSectionTitle "License"

        local options=(
            "Show"
            "Change"
            "Apply"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showLicenseCofing
                    break
                    ;;
                "${options[1]}")
                    configureLicense
                    break
                    ;;
                "${options[2]}")
                    applyLicenseConfigs
                    break
                    ;;
                "${options[3]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done

    return
}

function showLicenseCofing() {
    printSectionTitle "Current license configuration:"

    printfInfo "License key: $LICENSE_KEY"

    if [ "$LICENSE_KEY" == "" ]; then
        printfWarning "None"
    fi
    
    finishOption
}

function configureLicense() {
    printSectionTitle "Type the configurations:"

    printfInfo "Your MAC is: $MAC_FORMATTED_LOWERCASE"

    local license_key

    echo
    read -p "License key: " license_key </dev/tty
    LICENSE_KEY="$license_key"

    cp "$FILE_CONFIG_LICENSE_EXAMPLE" "$FILE_CONFIG_LICENSE"
    replaceStringInFile "$FILE_CONFIG_LICENSE" "LICENSE_KEY=\"\"" "LICENSE_KEY=\"$license_key\""

    finishOption
}

function applyLicenseConfigs() {
    printSectionTitle "Apllying current license configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    echo "$apply_config_license" | while IFS= read -r line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done

    sudo sync

    echo
    read -r -p "Would you like to restart easiboxsrv service? [y/n] " restart_easiboxsrv
    if [ "$restart_easiboxsrv" = "y" ] || [ "$restart_easiboxsrv" = "Y" ]; then
        runService "easiboxsrv"
    fi

    finishOption
}