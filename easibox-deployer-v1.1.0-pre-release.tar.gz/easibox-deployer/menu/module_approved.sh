apply_config_modules="
setModules
"

function showModulesOptions() {
    while true; do    
        printSectionTitle "Modules"

        local options=(
            "Show"
            "Change"
            "Apply"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showModulesConfigs
                    break
                    ;;
                "${options[1]}")
                    configureModules
                    break
                    ;;
                "${options[2]}")
                    applyModulesConfigs
                    break
                    ;;
                "${options[3]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}

function showModulesConfigs() {
    printSectionTitle "Current modules configuration:"

    local current_options=(
        "UsCallVoip = $PORT_USCALLVOIP"
        "Default = $PORT_DEFAULT"
        "Topsistemas = $PORT_TOPSISTEMAS"
        "EasiAlarm = $PORT_EASIALARM"
        "EasiProductLineMovement = $PORT_EASIPRODUCTLINEMOVEMENT"
    )

    for current_option in "${current_options[@]}"; do
        echo "$current_option"
    done

    finishOption
}

function configureModules() {
    while true; do
        printSectionTitle "Select a value to change:"

        local options=(
            "UsCallVoip"
            "Default"
            "Topsistemas"
            "EasiAlarm"
            "EasiProductLineMovement"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        local is_valid
        local COLUMNS=1
        select opt in "${options[@]}"; do
            is_valid=1

            case $opt in
                "${options[0]}") ;;
                "${options[1]}") ;;
                "${options[2]}") ;;
                "${options[3]}") ;;
                "${options[4]}") ;;
                "${options[5]}") return ;;
                *) is_valid=0; echo "invalid option $REPLY";;
            esac

            if [ $is_valid -eq 1 ]; then
                local key=$opt
                key="PORT_${key^^}"
                local old_value=${!key}

                configureGeneric "$FILE_CONFIG_MODULES" "$key" "$old_value"
                break
            fi
        done
    done

    finishOption
}

function applyModulesConfigs() {
    printSectionTitle "Apllying current modules configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    echo "$apply_config_modules" | while IFS= read -r line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done

    echo
    read -r -p "Would you like to restart easiboxsrv service? [y/n] " restart_easiboxsrv
    if [ "$restart_easiboxsrv" = "y" ] || [ "$restart_easiboxsrv" = "Y" ]; then
        runService "easiboxsrv"
    fi

    finishOption
}
