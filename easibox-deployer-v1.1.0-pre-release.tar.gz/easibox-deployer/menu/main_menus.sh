# The scripts are built to run multiple times (before and after the installation)
# Don't change the scripts order if you don't know what you're doing

deploy_full="
validateNetworkInterface
upgradeApt
installGeneralTools
createBaseDirs
disableNetworkCloudCfg
getBoxToken
getBoxInfo
setIPAddress
installCertificates
installMySQL
addMySQLUser
configureMySQL
executeMySQLService
installEASiBoxMigrate
applyMigrations
setAdvancedDBBeys
setLiceseDBKey
setNetworkInterfaceDBKey
setVersionDBKey
setModules
setNVRAndPOS
configureOpenVPN
executeOpenVPNService
installNTP
configureNTP
disableNTPDHCPOverride
executeNTPService
installMQTT
installLibSrtp
installLibNice
installCurl
installJanus
configureJanus
configureJanusStreaming
configureJanusMQTT
executeJanusService
installMongoDB
configureMongoDB
configureMongoDBComposeFile
deployMongoDB
installMosquitto
configureMosquitto
linkMosquittoCertificates
executeMosquittoService
initializeMongoDB
installZeep
installEASiBox
executeEasiboxService
executeEasiboxmidService
waitBeforeTesting
executeInstallationTests
"

deploy_config_full="
validateNetworkInterface
getBoxToken
getBoxInfo
setIPAddress
installCertificates
addMySQLUser
configureMySQL
executeMySQLService
setAdvancedDBBeys
setLiceseDBKey
setNetworkInterfaceDBKey
setModules
setNVRAndPOS
configureOpenVPN
executeOpenVPNService
configureNTP
executeNTPService
configureJanusStreaming
configureJanusMQTT
executeJanusService
configureMongoDB
configureMongoDBComposeFile
deployMongoDB
configureMosquitto
linkMosquittoCertificates
executeMosquittoService
executeEasiboxService
executeEasiboxmidService
waitBeforeTesting
executeInstallationTests
"

function startFullInstallation() {
    if [ "$URL_EASIBOX_PRODUCTION" = "" ] || [ "$URL_EASIBOX_MIGRATE" = "" ] || [ $VERSION_EASIBOX -eq 0 ]; then
        echo
        printfError "Installation is disabled due to missing configurations (URL_EASIBOX_PRODUCTION, URL_EASIBOX_MIGRATE, VERSION_EASIBOX)"
        finishOption
        return
    fi

    printSectionTitle "Starting full installation..."

    while read line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done <<< "$(echo -e "$deploy_full")"

    finishOption
}

function applyFullConfigs() {
    printSectionTitle "Apllying current configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    while read line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done <<< "$(echo -e "$deploy_config_full")"

    finishOption
}

function setFactoryApprovedMode() {
    printSectionTitle 'Factory Approved mode'

    printfInfo "Are you sure you want to convert EASiBox Deployer to Factory Approved mode?"
    echo

    local options=(
        "Yes"
        "No"
    )

    local PS3='Please enter your choice: '
    select opt in "${options[@]}"; do
        case $opt in
            "${options[0]}")
                echo
                printfInfo "Removing not approved menus"
                for file in $DIR_MENUS/*; do
                    if [[ "$file" != *"_approved"* ]]; then
                        rm "$file"
                        printfDebug "Removed menu: $file"
                    fi
                done

                printfInfo "Removing not approved scripts"
                for file in $DIR_SCRIPTS/*; do
                    if [[ "$file" != *"_approved"* ]]; then
                        rm "$file"
                        printfDebug "Removed script: $file"
                    fi
                done

                printfInfo "Setting to 'Factory Approved' mode"
                addStringToFile "$FILE_CONFIG" "PRODUCTION_MODE" "FACTORY_APPROVED_EASIBOX=1"

                if [ -d "$DIR_BASE/.git" ]; then
                    sudo rm -r "$DIR_BASE/.git"
                fi

                exit
                ;;
            "${options[1]}")
                return
                ;;
            *) echo "invalid option $REPLY";;
        esac
    done
}

function showConfigurations() {
    while true; do
        printSectionTitle "Configure" # Full

        local options=(
            "Advanced"
            "Certificates"
            "License"
            "Modules"
            "Network"
            "NVR"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showAdvancedOptions
                    break
                    ;;
                "${options[1]}")
                    showCertificatesOptions
                    break
                    ;;
                "${options[2]}")
                    showLicenseOptions
                    break
                    ;;
                "${options[3]}")
                    showModulesOptions
                    break
                    ;;
                "${options[4]}")
                    showNetworkOptions
                    break
                    ;;
                "${options[5]}")
                    showNVROptions
                    break
                    ;;
                "${options[6]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done

    return
}

function showAllOptions() {
    while true; do    
        printSectionTitle "Main menu" # Full

        local options=(
            "Configure"
            "Apply current configurations"
            "Start full instalation"
            "Update instalation"
            "Apply Factory Approved mode"
            "Run tests"
            "Quit"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showConfigurations
                    break
                    ;;
                "${options[1]}")
                    applyFullConfigs
                    break
                    ;;
                "${options[2]}")
                    startFullInstallation
                    break
                    ;;
                "${options[3]}")
                    showUpdateOptions
                    break
                    ;;
                "${options[4]}")
                    setFactoryApprovedMode
                    break
                    ;;
                "${options[5]}")
                    showTests
                    break
                    ;;
                "${options[6]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}