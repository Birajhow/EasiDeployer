function showTests() {
    while true; do    
        printSectionTitle "Tests"

        local options=(
            "Installation tests"
            "Ping EASiBox servers"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    testInstallation
                    break
                    ;;
                "${options[1]}")
                    testConnections
                    break
                    ;;
                "${options[2]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done

    return
}

function testInstallation() {
    printSectionTitle "Installation tests"

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    executeInstallationTests

    finishOption
}

function testConnection() {
    # $1 = url
    # $2 = port
    local url=$1
    local port=$2

    netcat -z -v -w3 $url $port &>>"$FILE_LOG";

    if [ $? -eq 0 ]; then
        printfInfo "$url:$port is accessible"
    else
        printfError "$url:$port is unreachable"
    fi
}

function testConnections() {
    printSectionTitle "Test connections"

    testConnection easi.live 443
    testConnection api.easi.live 443
    testConnection mqtt.easi.live 8883
    testConnection remote.easi.live 443
    testConnection easilive.s3.amazonaws.com 443

    finishOption
}
