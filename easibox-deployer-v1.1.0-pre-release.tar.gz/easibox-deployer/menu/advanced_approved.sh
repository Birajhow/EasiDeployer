apply_config_advanced="
setAdvancedDBBeys
"

function showAdvancedOptions() {
    while true; do    
        printSectionTitle "Advanced"

        local options=(
            "Show"
            "Change"
            "Apply"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showAdvancedConfigs
                    break
                    ;;
                "${options[1]}")
                    configureAdvanced
                    break
                    ;;
                "${options[2]}")
                    applyAdvancedConfigs
                    break
                    ;;
                "${options[3]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}

function showAdvancedConfigs() {
    printSectionTitle "Current advanced configuration:"

    local current_options=(
        "$(printf '%-30s %s' "CR_OVERLAY_ENABLED = $CR_OVERLAY_ENABLED" "# Turn on stream overlay")"
        "$(printf '%-30s %s' "FIX_SOCCIN = $FIX_SOCCIN" "# Fixes to the SOCCIN POS integration")"
        "$(printf '%-30s %s' "MAX_UPLOAD_SPEED = $MAX_UPLOAD_SPEED" "# Maximium video upload speed")"
        "$(printf '%-30s %s' "VIDEO_AND_AUDIO = $VIDEO_AND_AUDIO" "# Enable camera audio capturing")"
    )

    for current_option in "${current_options[@]}"; do
        echo "$current_option"
    done

    finishOption
}

function configureAdvanced() {
    while true; do
        printSectionTitle "Select a value to change:"

        local options=(
            "CR_OVERLAY_ENABLED"
            "FIX_SOCCIN"
            "MAX_UPLOAD_SPEED"
            "VIDEO_AND_AUDIO"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        local is_valid
        local COLUMNS=1
        select opt in "${options[@]}"; do
            is_valid=1

            case $opt in
                "${options[0]}") ;;
                "${options[1]}") ;;
                "${options[2]}") ;;
                "${options[3]}") ;;
                "${options[4]}") return ;;
                *) is_valid=0; echo "invalid option $REPLY";;
            esac

            if [ $is_valid -eq 1 ]; then
                local key=$opt
                local old_value=${!key}

                configureGeneric "$FILE_CONFIG_ADVANCED" "$key" "$old_value"
                break
            fi
        done
    done

    finishOption
}

function applyAdvancedConfigs() {
    printSectionTitle "Apllying current advanced configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    echo "$apply_config_advanced" | while IFS= read -r line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done

    finishOption
}

