apply_config_nvr="
setNVRAndPOS
configureJanusStreaming
configureJanusMQTT
"

function showNVROptions() {
    while true; do    
        printSectionTitle "NVR"

        local options=(
            "Show"
            "Change"
            "Apply"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showNVRCofing
                    break
                    ;;
                "${options[1]}")
                    configureNVR
                    break
                    ;;
                "${options[2]}")
                    applyNVRConfigs
                    break
                    ;;
                "${options[3]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done 
}

function showNVRCofing() {
    printSectionTitle "Current NVR configuration:"

    if [ "$CAMERAS_NVR" == "" ]; then
        printfWarning "NVR is not configured"
    else
        local camera_counter=1
        local camera_line_counter=0

        while read line; do
            if [ "$line" = "===" ]; then
                camera_counter=$((camera_counter + 1))
                camera_line_counter=0
            else
                camera_line_counter=$((camera_line_counter + 1))

                case $camera_line_counter in
                    1)
                        echo
                        printfInfo "Camera $camera_counter:"
                        echo
                        printfInfo "POS: $line"
                        ;;
                    2)
                        printfInfo "NVR host: $line"
                        ;;
                    3)
                        printfInfo "NVR port: $line"
                        ;;
                    4)
                        printfInfo "NVR schema: $line"
                        ;;
                    5)
                        printfInfo "NVR user: $line"
                        ;;
                    6)
                        printfInfo "NVR password: $line"
                        ;;
                    7)
                        printfInfo "NVR RTSP port: $line"
                        ;;
                    8)
                        printfInfo "NVR auth mode: $line"
                        ;;
                    9)
                        printfInfo "NVR camera channel: $line"
                        ;;
                    10)
                        printfInfo "NVR camera subchannel: $line"
                        ;;
                    11)
                        printfInfo "NVR camera audio: $line"
                        ;;
                    12)
                        printfInfo "Camera brand: $line"
                        ;;
                    13)
                        printfInfo "Camera idx: $line"
                        ;;
                    *);;
                esac
            fi
        done <<< "$(echo -e "$CAMERAS_NVR")"
    fi

    finishOption
}

function configureNVR() {
    printSectionTitle "Enter the configurations:"

    local number_cameras=0
    local reconfigure
    local aimed_pos
    local pos_list

    if [ "$CAMERAS_NVR" != "" ]; then
        read -r -p "Do you want to start with the current configurations? [y/n] " reconfigure </dev/tty
        if [ "$reconfigure" = "y" ] || [ "$reconfigure" = "Y" ]; then
            number_cameras=$(grep -o '===' <<<"$CAMERAS_NVR" | grep -c .)
            echo
            printfInfo "Number of cameras: $number_cameras"
            echo
            read -r -p "Select a camera (or leave empty to modify all): " aimed_pos </dev/tty
        fi
    fi

    if [ "$POS_LIST_STORE" = "" ] && [ $number_cameras -eq 0 ]; then
        echo
        getBoxToken
        getBoxInfo
    fi

    if [ "$POS_LIST_STORE" != "" ] && [ $number_cameras -eq 0 ]; then
        pos_list=(${POS_LIST_STORE// / })
        camera_list=(${CAMERA_LIST_STORE// / })
        number_cameras=$(grep -o ' ' <<<"$POS_LIST_STORE" | grep -c .)
        number_cameras=$((number_cameras + 1))
        echo
        printfInfo "Number of cameras: $number_cameras"
    fi

    if [ $number_cameras -eq 0 ]; then
        read -r -p "Number of cameras: " number_cameras </dev/tty
    fi

    [ $number_cameras -gt 0 ] 2>/dev/null
    if [ $? -ne 0 ]; then
        printfError "Invalid number of cameras"
        finishOption
        return
    fi

    echo
    printfInfo "Available camera brands:"

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfWarning "MySQL is not running. Unable to show options"
    else
        printfInfo "$(sudo mysql $DATABASE_MYSQL -tse "SELECT * FROM \`tbl_camera_brand\`")"
    fi

    local pos=0
    local host_nvr
    local port_nvr=80
    local schema_nvr="http://"
    local user_nvr="admin"
    local password_nvr
    local port_rtsp_nvr=554
    local auth_mode_nvr=0
    local channel_camera_nvr=$((FIRST_CHANNEL_JANUS_CAMERAS - 1))
    local channel_extra_camera_nvr="01"
    local brand_camera=1
    local idx_camera
    local audio_camera_nvr=0

    local cameras_nvr
    local camera_nvr

    local reconfiruge_camera_counter
    local reconfiruge_valid_line_counter

    for (( i=1; i<=$number_cameras; i++ )); do
        channel_camera_nvr=$((channel_camera_nvr + 1))

        if [ "$camera_list" != "" ]; then
            idx_camera=${camera_list[$((i-1))]}
        else
            idx_camera=""
        fi

        if [ "$pos_list" != "" ]; then
            pos=${pos_list[$((i-1))]}
        else
            pos=$((pos + 1))
        fi

        # Override last values if the user wishes to
        if [ "$reconfigure" = "y" ]; then
            reconfiruge_camera_counter=0
            reconfiruge_valid_line_counter=0

            while read line; do
                if [ "$line" = "===" ]; then
                    reconfiruge_camera_counter=$((reconfiruge_camera_counter + 1))
                elif [ $reconfiruge_camera_counter -eq $(($i - 1)) ]; then
                    reconfiruge_valid_line_counter=$((reconfiruge_valid_line_counter + 1))

                    case $reconfiruge_valid_line_counter in
                        1)
                            pos="$line"
                            ;;
                        2)
                            host_nvr="$line"
                            ;;
                        3)
                            port_nvr="$line"
                            ;;
                        4)
                            schema_nvr="$line"
                            ;;
                        5)
                            user_nvr="$line"
                            ;;
                        6)
                            password_nvr="$line"
                            ;;
                        7)
                            port_rtsp_nvr="$line"
                            ;;
                        8)
                            auth_mode_nvr="$line"
                            ;;
                        9)
                            channel_camera_nvr="$line"
                            ;;
                        10)
                            channel_extra_camera_nvr="$line"
                            ;;
                        11)
                            audio_camera_nvr="$line"
                            ;;
                        12)
                            brand_camera="$line"
                            ;;
                        13)
                            idx_camera="$line"
                            ;;
                        *);;
                    esac
                fi
            done <<< "$(echo -e "$CAMERAS_NVR")"
        fi

        if [ "$aimed_pos" != "" ] && [ $i -ne $aimed_pos ]; then
            :
        else
            echo
            printfInfo "Camera $i:"
            echo

            read -e -p "POS: " -i "$pos" pos </dev/tty
            read -e -p "NVR host: " -i "$host_nvr" host_nvr </dev/tty
            read -e -p "NVR port: " -i "$port_nvr" port_nvr </dev/tty
            read -e -p "NVR schema: " -i "$schema_nvr" schema_nvr </dev/tty
            read -e -p "NVR user: " -i "$user_nvr" user_nvr </dev/tty
            read -e -p "NVR password: " -i "$password_nvr" password_nvr </dev/tty
            read -e -p "NVR RTSP port: " -i "$port_rtsp_nvr" port_rtsp_nvr </dev/tty
            read -e -p "NVR auth mode: " -i "$auth_mode_nvr" auth_mode_nvr </dev/tty
            read -e -p "NVR camera channel: " -i "$channel_camera_nvr" channel_camera_nvr </dev/tty
            read -e -p "NVR camera subchannel: " -i "$channel_extra_camera_nvr" channel_extra_camera_nvr </dev/tty
            read -e -p "NVR camera audio: " -i "$audio_camera_nvr" audio_camera_nvr </dev/tty
            read -e -p "Camera brand: " -i "$brand_camera" brand_camera </dev/tty
            read -e -p "Camera idx: " -i "$idx_camera" idx_camera </dev/tty
        fi

        camera_nvr="""$pos
$host_nvr
$port_nvr
$schema_nvr
$user_nvr
$password_nvr
$port_rtsp_nvr
$auth_mode_nvr
$channel_camera_nvr
$channel_extra_camera_nvr
$audio_camera_nvr
$brand_camera
$idx_camera
==="""

        if [ "$cameras_nvr" == "" ]; then
            cameras_nvr="$camera_nvr"
        else
            cameras_nvr="""$cameras_nvr
$camera_nvr"""
        fi
    done

    cp "$FILE_CONFIG_NVR_EXAMPLE" "$FILE_CONFIG_NVR"
    addStringToFile "$FILE_CONFIG_NVR" "CAMERAS_NVR=\"\"" "CAMERAS_NVR=\"$cameras_nvr\""
    replaceStringInFile "$FILE_CONFIG_NVR" "CAMERAS_NVR=\"\"" ''

    export "CAMERAS_NVR=$cameras_nvr"

    finishOption
}

function applyNVRConfigs() {
    printSectionTitle "Apllying current NVR configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    echo "$apply_config_nvr" | while IFS= read -r line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done

    sudo sync

    finishOption
}