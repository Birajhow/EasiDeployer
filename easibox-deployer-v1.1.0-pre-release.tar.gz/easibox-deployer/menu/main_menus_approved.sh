# The scripts are built to run multiple times (before and after the installation)
# Don't change the scripts order if you don't know what you're doing

deploy_config_approved="
validateNetworkInterface
getBoxToken
getBoxInfo
setAdvancedDBBeys
setNetworkInterfaceDBKey
setIPAddress
setModules
setNVRAndPOS
configureJanusStreaming
configureJanusMQTT
executeJanusService
configureMosquitto
linkMosquittoCertificates
executeMosquittoService
executeEasiboxService
executeEasiboxmidService
waitBeforeTesting
executeInstallationTests
"

function applyFactoryApprovedConfigs() {
    printSectionTitle "Apllying current configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    while read line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done <<< "$(echo -e "$deploy_config_approved")"

    finishOption
}

function showFactoryApprovedConfigs() {
    while true; do
        printSectionTitle "Configure" # Factory Approved

        local options=(
            "Advanced"
            "Module"
            "Network"
            "NVR"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showAdvancedOptions
                    break
                    ;;
                "${options[1]}")
                    showModulesOptions
                    break
                    ;;
                "${options[2]}")
                    showNetworkOptions
                    break
                    ;;
                "${options[3]}")
                    showNVROptions
                    break
                    ;;
                "${options[4]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}

function showFactoryApprovedOptions() {
    while true; do    
        printSectionTitle "Main menu" # Factory Approved

        local options=(
            "Configure"
            "Apply current configurations"
            "Update installation"
            "Run tests"
            "Quit"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showFactoryApprovedConfigs
                    break
                    ;;
                "${options[1]}")
                    applyFactoryApprovedConfigs
                    break
                    ;;
                "${options[2]}")
                    showUpdateOptions
                    break
                    ;;
                "${options[3]}")
                    showTests
                    break
                    ;;
                "${options[4]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}