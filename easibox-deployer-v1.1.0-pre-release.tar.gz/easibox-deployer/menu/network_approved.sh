apply_config_network="
validateNetworkInterface
setIPAddress
"

function showNetworkCofing() {
    printSectionTitle "Script network configuration:"

    isInternalIPDynamic
    local is_internal_ip_dynamic=$?
    local is_applied

    if [ "$IP_INTERNAL_STATIC" != "" ]; then
        submask_custom="$(getSubmaskIP $SUBMASK_CUSTOM)"

        printfInfo "Type: static"
        echo
        printfInfo "Internal IP: $IP_INTERNAL_STATIC"
        printfInfo "Interface: $NETWORK_INTERFACE_CUSTOM"
        printfInfo "Subnet mask: $submask_custom"
        printfInfo "Gateway: $GATEWAY_CUSTOM"
        printfInfo "DNS Primary: $NAMESERVER_PRIMARY_CUSTOM"
        printfInfo "DNS Secondary: $NAMESERVER_SECONDARY_CUSTOM"
        echo

        is_applied="no"
        if [ "$IP_INTERNAL_STATIC" != "" ] && [ $is_internal_ip_dynamic -eq 0 ]; then
            local nameservers="$(cat "$FILE_NETPLAN" | grep "addresses: \[")"

            local dns1_active=1 # This must exist
            local dns2_active=0
            if echo "$nameservers" | grep -q ','; then
                dns2_active=1
            fi

            if cat "$FILE_NETPLAN" | grep -q "$NETWORK_INTERFACE_CUSTOM" &&
            cat "$FILE_NETPLAN" | grep -q "$GATEWAY_CUSTOM" &&
            cat "$FILE_NETPLAN" | grep -q "$IP_INTERNAL_STATIC" &&
            ( [ "$NAMESERVER_PRIMARY_CUSTOM" = "" ] && [ $dns1_active -eq 0 ] || [ "$NAMESERVER_PRIMARY_CUSTOM" != "" ] && cat "$FILE_NETPLAN" | grep -q "$NAMESERVER_PRIMARY_CUSTOM" ) &&
            ( [ "$NAMESERVER_SECONDARY_CUSTOM" = "" ] && [ $dns2_active -eq 0 ] || [ "$NAMESERVER_SECONDARY_CUSTOM" != "" ] && cat "$FILE_NETPLAN" | grep -q "$NAMESERVER_SECONDARY_CUSTOM" ) &&
            cat "$FILE_NETPLAN" | grep -q "$SUBMASK_CUSTOM"; then
                is_applied="yes"
            fi
        fi

        printfWarning "Is applied: $is_applied"
    else
        submask="$(getSubmaskIP $SUBMASK)"

        printfInfo "Type: dynamic"
        echo
        printfInfo "Internal IP: $IP_INTERNAL"
        printfInfo "Interface: $NETWORK_INTERFACE"
        printfInfo "Subnet mask: $submask"
        printfInfo "Gateway: $GATEWAY"
        printfInfo "DNS Primary: $NAMESERVER_PRIMARY"
        printfInfo "DNS Secondary: $NAMESERVER_SECONDARY"
        echo

        local is_applied="no"
        if [ $is_internal_ip_dynamic -eq 1 ]; then
            is_applied="yes"
        fi

        printfWarning "Is applied: $is_applied"
    fi

    finishOption
}

function configureNetwork() {
    printSectionTitle "Type the configurations:"

    printfInfo "Leave the IP empty to use DHCP"

    echo 
    printfInfo "Network interfaces:"
    printfInfo "$(showPhysicalNetworkInterfaceNames)"

    if [ "$IP_INTERNAL_STATIC" != "" ]; then
        local old_interface="$NETWORK_INTERFACE_CUSTOM"
        local old_ip="$IP_INTERNAL_STATIC"
        local old_submask="$(getSubmaskIP $SUBMASK_CUSTOM)"
        local old_gateway="$GATEWAY_CUSTOM"
        local old_dns1="$NAMESERVER_PRIMARY_CUSTOM"
        local old_dns2="$NAMESERVER_SECONDARY_CUSTOM"
    else
        local old_interface="$NETWORK_INTERFACE"
        local old_ip="$IP_INTERNAL"
        local old_submask="$(getSubmaskIP $SUBMASK)"
        local old_gateway="$GATEWAY"
        local old_dns1=""
        local old_dns2=""
    fi

    local interface_custom
    local internal_ip_static
    local submask_custom
    local gateway_custom
    local nameserver_primary_custom
    local nameserver_secondary_custom

    echo
    read -e -p "Static internal IP: " -i "$old_ip" internal_ip_static </dev/tty
    IP_INTERNAL_STATIC="$internal_ip_static"
    if [ "$internal_ip_static" = "" ]; then
        echo
        printfInfo "DHCP will be used"
        cp "$FILE_CONFIG_NETWORK_EXAMPLE" "$FILE_CONFIG_NETWORK"
    else
        read -e -p "Network interface: " -i "$old_interface" interface_custom </dev/tty
        NETWORK_INTERFACE_CUSTOM="$interface_custom"
        read -e -p "Subnet mask: " -i "$old_submask" submask_custom </dev/tty
        getSubmaskBits "$submask_custom"
        submask_custom="$?"
        SUBMASK_CUSTOM="$submask_custom"
        read -e -p "Gateway: " -i "$old_gateway" gateway_custom </dev/tty
        GATEWAY_CUSTOM="$gateway_custom"
        read -e -p "Primary DNS: " -i "$old_dns1" nameserver_primary_custom </dev/tty
        NAMESERVER_PRIMARY_CUSTOM="$nameserver_primary_custom"
        read -e -p "Secondary DNS: " -i "$old_dns2" nameserver_secondary_custom </dev/tty
        NAMESERVER_SECONDARY_CUSTOM="$nameserver_secondary_custom"

        cp "$FILE_CONFIG_NETWORK_EXAMPLE" "$FILE_CONFIG_NETWORK"
        replaceStringInFile "$FILE_CONFIG_NETWORK" "NETWORK_INTERFACE_CUSTOM=\"\"" "NETWORK_INTERFACE_CUSTOM=\"$interface_custom\""
        replaceStringInFile "$FILE_CONFIG_NETWORK" "IP_INTERNAL_STATIC=\"\"" "IP_INTERNAL_STATIC=\"$internal_ip_static\""
        replaceStringInFile "$FILE_CONFIG_NETWORK" "SUBMASK_CUSTOM=\"\"" "SUBMASK_CUSTOM=\"$submask_custom\""
        replaceStringInFile "$FILE_CONFIG_NETWORK" "GATEWAY_CUSTOM=\"\"" "GATEWAY_CUSTOM=\"$gateway_custom\""
        replaceStringInFile "$FILE_CONFIG_NETWORK" "NAMESERVER_PRIMARY_CUSTOM=\"\"" "NAMESERVER_PRIMARY_CUSTOM=\"$nameserver_primary_custom\""
        replaceStringInFile "$FILE_CONFIG_NETWORK" "NAMESERVER_SECONDARY_CUSTOM=\"\"" "NAMESERVER_SECONDARY_CUSTOM=\"$nameserver_secondary_custom\""
    fi

    finishOption
}

function applyNetworkConfigs() {
    printSectionTitle "Apllying current network configurations..."

    if [ ! -d "$DIR_EASIBOX_BASE/easiboxsrv" ]; then
        printfError "Unable to apply settings, EASiBox is not installed"
        finishOption
        return
    fi

    while read line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done <<< "$(echo -e "$apply_config_network")"

    sudo sync

    finishOption
}

function showNetworkOptions() {
    while true; do    
        printSectionTitle "Network"

        local options=(
            "Show"
            "Change"
            "Apply"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    showNetworkCofing
                    break
                    ;;
                "${options[1]}")
                    configureNetwork
                    break
                    ;;
                "${options[2]}")
                    applyNetworkConfigs
                    break
                    ;;
                "${options[3]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}