deploy_update="
installEASiBoxMigrate
applyMigrations
setVersionDBKey
installEASiBox
executeEasiboxService
executeEasiboxmidService
"

function showUpdateOptions() {
    while true; do    
        printSectionTitle "Update installation"

        local options=(
            "Latest version"
            "Select newer version"
            "Return"
        )

        local PS3="$(printf '\nPlease enter your choice: ')"
        select opt in "${options[@]}"; do
            case $opt in
                "${options[0]}")
                    updateInstallation
                    break
                    ;;
                "${options[1]}")
                    selectVersion
                    break
                    ;;
                "${options[2]}")
                    return
                    ;;
                *) echo "invalid option $REPLY";;
            esac
        done
    done
}

function selectVersion() {
    local response=$(wget -qO- $URL_EASIBOX_UPDATE)

    if echo "$response" | grep -q "error" || [ "$response" == "" ]; then
        printfError "Failed to get EASiBox versions list"
        return
    fi

    local options=()
    local versions
    declare -A versions
    local version_easibox_formatted=$(echo $VERSION_EASIBOX | tr -d '.')
    local key_check

    while IFS='¨' read key value; do
        key_check=$(echo $key | tr -d '.')
        if [[ $key_check -gt $version_easibox_formatted ]]; then
            versions[$key]=$value
            options+=($key)
        fi
    done <<< "$(jq -r 'to_entries | map(.key + "¨" + (.value | tostring)) | .[]' <<< "$response")"

    options+=("Return")

    while true; do
        printSectionTitle "Select a newer version:"

        local PS3="$(printf '\nPlease enter your choice: ')"
        local is_valid
        local COLUMNS=1
        select opt in "${options[@]}"; do
            is_valid=1

            case $opt in
                "Return") return ;;
                *);;
            esac

            if [[ ! -v "versions[$opt]" ]] ; then
                echo "invalid option $opt"
            else
                response=$(wget -qO- ${versions[$opt]})

                if echo "$response" | grep -q "error" || [ "$response" == "" ]; then
                    printfError "Failed to get EASiBox version links"
                    return
                fi

                local older_url_easibox_production=$URL_EASIBOX_PRODUCTION
                local older_url_easibox_migrate=$URL_EASIBOX_MIGRATE
                local older_new_version_easibox=$NEW_VERSION_EASIBOX
                local older_restart_mid_on_update=$RESTART_MID_ON_UPDATE

                while IFS='¨' read key value; do
                    printfDebug "$key = $value"
                    export "$key=$value"
                done <<< "$(jq -r 'to_entries | map(.key + "¨" + (.value | tostring)) | .[]' <<< "$response")"

                updateInstallation

                if [ $? -ne 0 ]; then
                    URL_EASIBOX_PRODUCTION=$older_url_easibox_production
                    URL_EASIBOX_MIGRATE=$older_url_easibox_migrate
                    NEW_VERSION_EASIBOX=$older_new_version_easibox
                    RESTART_MID_ON_UPDATE=$older_restart_mid_on_update
                fi

                return
            fi
        done
    done

    finishOption
}

function updateInstallation() {
    if [ "$URL_EASIBOX_PRODUCTION" = "" ] || [ "$URL_EASIBOX_MIGRATE" = "" ] || [ $VERSION_EASIBOX -eq 0 ]; then
        echo
        printfError "Updating is disabled due to missing configurations (URL_EASIBOX_PRODUCTION, URL_EASIBOX_MIGRATE, VERSION_EASIBOX)"
        finishOption
        return 1
    fi

    printSectionTitle "Updating installation..."

    commandExists "mysql"
    if [ "$?" -eq 0 ]; then
        printfError "MySQL is not installed. Repair or finish the full EASiBox installation"
        finishOption
        return 1
    fi

    local apply_update

    local restart_mid_on_update=false
    if [ $RESTART_MID_ON_UPDATE = true ] && [ "$VERSION_EASIBOX" != "$NEW_VERSION_EASIBOX" ]; then
        restart_mid_on_update=true
    fi

    printfInfo "Current version: $VERSION_EASIBOX"
    printfInfo "New version: $NEW_VERSION_EASIBOX"
    printfWarning "Mid restart is needed: $restart_mid_on_update"

    local version_easibox_formatted=$(echo $VERSION_EASIBOX | tr -d '.')
    local new_version_easibox_formatted=$(echo $NEW_VERSION_EASIBOX | tr -d '.')

    echo

    if [ "$VERSION_EASIBOX" = "$NEW_VERSION_EASIBOX" ]; then
        apply_update="n"
        if [ "$FORCE_EXEC" = "" ]; then
            read -r -p "Proceed with reinstall? [y/n] " apply_update
        else
            printfInfo "No need to update (v$NEW_VERSION_EASIBOX)"
        fi
    else
        apply_update="y"
        if [ "$FORCE_EXEC" = "" ]; then
            if [ "$new_version_easibox_formatted" -gt "$version_easibox_formatted" ]; then
                read -r -p "Proceed with update? [y/n] " apply_update
            else
                # Downgrade is disabled (older versions are hidden).
                printfWarning "You want to downgrade the system, this can lead to execution errors"
                read -r -p "Proceed with downgrade? [y/n] " apply_update
            fi
        else
            printfInfo "Updating from EASiBox v$VERSION_EASIBOX to v$NEW_VERSION_EASIBOX..."
        fi
    fi

    if [ "$apply_update" != "y" ]; then
        return 1
    else
        echo
    fi

    local initial_block_mid_restart=$BLOCK_EASIBOX_MID_RESTART

    if [ $restart_mid_on_update = false ]; then
        BLOCK_EASIBOX_MID_RESTART=1  
    fi

    VERSION_EASIBOX=$NEW_VERSION_EASIBOX
    echo "$deploy_update" | while IFS= read -r line; do
        if [ "$line" != "" ]; then
            $line
        fi
    done

    printfInfo "Getting EASiBox extra updates"

    local response
    local key_check

    response=$(wget -qO- $URL_EASIBOX_UPDATE_EXTRA)

    if [ "$response" == "" ]; then
        printfError "Failed to get links. Skipping step"
        return 1
    else
        while IFS='¨' read key value; do
            key_check=$(echo $key | tr -d '.')
            if [[ $key_check -gt $version_easibox_formatted ]]; then
                printfHr "Running extra update for v$key"
                response2=$(wget -qO- $value)
                eval "${response2}"
            fi
        done <<< "$(jq -r 'to_entries | map(.key + "¨" + (.value | tostring)) | .[]' <<< "$response")"
    fi

    BLOCK_EASIBOX_MID_RESTART=$initial_block_mid_restart

    finishOption

    return 0
}