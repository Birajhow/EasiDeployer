function setkeyValue() {
    # $1 = Database name
    # $2 = Table filename
    # $3 = Key
    # $4 = Value
    local db=$1
    local tbl=$2
    local key=$3
    local value=$4
    
    local key_exists=$(sudo mysql $db -se "SELECT idx FROM \`$tbl\` WHERE \`key\` = '$key'")

    if [ "$key_exists" != "" ]; then
        echo "
            USE $db;
            UPDATE $tbl SET \`value\`='$value' WHERE \`key\`='$key';
        " > ~/temp.sql
    else
        echo "
            USE $db;
            INSERT INTO \`$tbl\`
                (\`key\`, \`value\`)
            VALUES
                ('$key', $value);
        " > ~/temp.sql
    fi

    local res=$(sudo mysql < ~/temp.sql 2>&1 >/dev/null)
    if echo $res | grep -q "ERROR"; then
        printfError "Failed to set $key"
        echo $res &>>"$FILE_LOG";
    else
        printfDebug "$key = $value"
    fi
    rm ~/temp.sql
}