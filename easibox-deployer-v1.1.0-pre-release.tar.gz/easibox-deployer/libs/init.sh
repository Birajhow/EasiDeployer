#!/bin/bash
#    Based on Tux-Deployer
#    https://github.com/Xalalau/Tux-Deployer

SCRIPT_NAME="EASiBox Deployer"
SCRIPT_VERSION="1.1.0 Pre Release"
SCRIPT_LICENSE="""
    Inwave © - Version: $SCRIPT_VERSION
    An easy way to deploy the EASiBox solution"""

function installAPTDependency() {
    local command=$1
    local package=$2
    local installed_dependencies=$3

    commandExists "$command"
    if [ "$?" -ne 1 ]; then
        if [ "$installed_dependencies" -eq 0 ]; then
            upgradeApt
        fi

        installApt "$package"

        commandExists "$command"
        if [ "$?" -ne 1 ]; then
            printfCritical "$package is needed in order to execute the script"
        fi

        return 1
    fi

    return 0
}

function checkDependencies() {
    sleep 0.3
    printfInfo "Checking script dependencies"

    local installed_dependencies=0

    installAPTDependency 'awk' 'awk' $installed_dependencies
    if [ "$?" -eq 1 ]; then
        installed_dependencies=1
    fi

    installAPTDependency 'curl' 'curl' $installed_dependencies
    if [ "$?" -eq 1 ]; then
        installed_dependencies=1
    fi

    installAPTDependency 'unzip' 'unzip' $installed_dependencies
    if [ "$?" -eq 1 ]; then
        installed_dependencies=1
    fi

    installAPTDependency 'unrar' 'unrar' $installed_dependencies
    if [ "$?" -eq 1 ]; then
        installed_dependencies=1
    fi

    installAPTDependency 'jq' 'jq' $installed_dependencies
    if [ "$?" -eq 1 ]; then
        installed_dependencies=1
    fi

    if [ $ENABLE_FLATPAK -eq 1 ]; then
        installAPTDependency 'flatpak' 'flatpak' $installed_dependencies
        if [ "$?" -eq 1 ]; then
            installed_dependencies=1
        fi
    fi

    if [ $ENABLE_SNAP -eq 1 ]; then
        commandExists "snap" 

        if [ "$?" -ne 1 ]; then
            if [ -f "/etc/apt/preferences.d/nosnap.pref" ]; then # Linux Mint
                sudo rm "/etc/apt/preferences.d/nosnap.pref"
                sudo apt update &>>"$FILE_LOG";
            fi

            installAPTDependency 'snap' 'snapd' $installed_dependencies
            if [ "$?" -eq 1 ]; then
                installed_dependencies=1
            fi
        fi
    fi

    if [ $ENABLE_GDRIVE_DOWNLOAD_URLS -eq 1 ]; then
        installAPTDependency 'pip3' 'python3-pip' $installed_dependencies
        if [ "$?" -eq 1 ]; then
            installed_dependencies=1
        fi

        commandExists "gdown"
        if [ "$?" -ne 1 ]; then
            printfInfo "Installing: gdown"
            sudo pip3 install gdown &>>"$FILE_LOG";
            commandExists "gdown"
            if [ "$?" -ne 1 ]; then
                printfError "Failed to install: gdown"
                printfCritical "gdown is needed in order to execute the script"
            else
                printfDebug "Installed: gdown"
            fi
            installed_dependencies=1
        fi
    fi
}

function getRemoteConfigurations() {
    printfInfo "Getting EASiBox links"

    local response=$(wget -qO- $URL_EASIBOX_UPDATE)

    function printFailToGetLinks() {
        if [ "$URL_EASIBOX_PRODUCTION" = "" ] || [ "$URL_EASIBOX_MIGRATE" = "" ] || [ $VERSION_EASIBOX -eq 0 ]; then
            printfError "Failed to get latest EASiBox version links. Manually set URL_EASIBOX_PRODUCTION, URL_EASIBOX_MIGRATE and VERSION_EASIBOX in the config.sh file to enable the installation and update functions."
            sleep 8
        else
            printfWarning "Failed to get latest EASiBox version links. Using manually set values."
            sleep 3
        fi
    }

    if echo "$response" | grep -q "error" || [ "$response" == "" ]; then
        printFailToGetLinks
        return
    else
        local latest_version=0
        local latest_version_link
        local key_check

        while IFS='¨' read key value; do
            key_check=$(echo $key | tr -d '.')
            if [[ $key_check -gt $latest_version ]]; then
                latest_version=$key_check
                latest_version_link=$value
            fi
        done <<< "$(jq -r 'to_entries | map(.key + "¨" + (.value | tostring)) | .[]' <<< "$response")"

        response=$(wget -qO- $latest_version_link)

        if echo "$response" | grep -q "error" || [ "$response" == "" ]; then
            printFailToGetLinks
            return
        fi

        while IFS='¨' read key value; do
            if [ ! -z "${!key}" ]; then
                printfDebug "Using predefined $key"
            else
                printfDebug "$key = $value"
                export "$key=$value"
            fi
        done <<< "$(jq -r 'to_entries | map(.key + "¨" + (.value | tostring)) | .[]' <<< "$response")"
    fi
}

function showHeader() {
    printfHr "$SCRIPT_NAME"
    printfHr "$SCRIPT_LICENSE"
    printfInfo "    Log: $NOW_FORMATED.txt"
    printfWarning "    To stop the script at any time, press CTRL+C."
    echo
}

#DISTRIB_ID, DISTRIB_RELEASE, DISTRIB_CODENAME, DISTRIB_DESCRIPTION
if [ -f "/etc/upstream-release/lsb-release" ]; then # Linux Mint
    source "/etc/upstream-release/lsb-release"
else
    source "/etc/lsb-release"
fi

NOW="$(date)"
NOW_FORMATED="$(echo $NOW | tr -s '[:blank:]' '_')"

DIR_LIBS="$DIR_BASE/libs"
DIR_LOGS="$DIR_BASE/logs"
DIR_SCRIPTS="$DIR_BASE/scripts"
DIR_CONFIGS="$DIR_BASE/configs"
DIR_MENUS="$DIR_BASE/menu"
DIR_NETWORK="/etc/netplan"

FILE_LOG="$DIR_LOGS/$NOW_FORMATED.txt"
FILE_NETPLAN="$(cd "$DIR_NETWORK"; for file in *; do echo "$DIR_NETWORK/$file"; done;)"

FILE_CONFIG="$DIR_CONFIGS/config.sh"
FILE_CONFIG_EXAMPLE="$DIR_CONFIGS/config.sh.example"
FILE_CONFIG_NETWORK="$DIR_CONFIGS/config_network.sh"
FILE_CONFIG_NETWORK_EXAMPLE="$DIR_CONFIGS/config_network.sh.example"
FILE_CONFIG_NVR="$DIR_CONFIGS/config_nvr.sh"
FILE_CONFIG_NVR_EXAMPLE="$DIR_CONFIGS/config_nvr.sh.example"
FILE_CONFIG_CERTIFICATES="$DIR_CONFIGS/config_certificates.sh"
FILE_CONFIG_CERTIFICATES_EXAMPLE="$DIR_CONFIGS/config_certificates.sh.example"
FILE_CONFIG_LICENSE="$DIR_CONFIGS/config_license.sh"
FILE_CONFIG_LICENSE_EXAMPLE="$DIR_CONFIGS/config_license.sh.example"
FILE_CONFIG_ADVANCED="$DIR_CONFIGS/config_advanced.sh"
FILE_CONFIG_ADVANCED_EXAMPLE="$DIR_CONFIGS/config_advanced.sh.example"
FILE_CONFIG_MODULES="$DIR_CONFIGS/config_modules.sh"
FILE_CONFIG_MODULES_EXAMPLE="$DIR_CONFIGS/config_modules.sh.example"

COLOR_BACKGROUND="\033[40m" # Magenta

STYLE_DEBUG="\e[1;37m" # White
STYLE_INFO="\e[1;36m" # Cyan
STYLE_WARNING="\e[1;33m" # Yellow
STYLE_FAILED="\e[1;31m" # Red
STYLE_CRITICAL="\e[1;31m" # Red
STYLE_HR="\e[1;32m" # Green
STYLE_TITLE="\e[4;1;32m" # Green + underline

ARCH="$(dpkg --print-architecture)"

USER_CURRENT="$(whoami)"

if [ ${DISTRIB_RELEASE:0:2} -ge 22 ]; then
    IS_APT_KEY_DEPRECATED=1
else
    export APT_KEY_DONT_WARN_ON_DANGEROUS_USAGE=1 # Hide a warning since Ubuntu 18.04
    IS_APT_KEY_DEPRECATED=0
fi

if [ ! -f "$FILE_CONFIG" ]; then
    cp "$FILE_CONFIG_EXAMPLE" "$FILE_CONFIG"
fi

if [ ! -f "$FILE_CONFIG_NETWORK" ]; then
    cp "$FILE_CONFIG_NETWORK_EXAMPLE" "$FILE_CONFIG_NETWORK"
fi

if [ ! -f "$FILE_CONFIG_NVR" ]; then
    cp "$FILE_CONFIG_NVR_EXAMPLE" "$FILE_CONFIG_NVR"
fi

if [ ! -f "$FILE_CONFIG_CERTIFICATES" ]; then
    cp "$FILE_CONFIG_CERTIFICATES_EXAMPLE" "$FILE_CONFIG_CERTIFICATES"
fi

if [ ! -f "$FILE_CONFIG_LICENSE" ]; then
    cp "$FILE_CONFIG_LICENSE_EXAMPLE" "$FILE_CONFIG_LICENSE"
fi

if [ ! -f "$FILE_CONFIG_ADVANCED" ]; then
    cp "$FILE_CONFIG_ADVANCED_EXAMPLE" "$FILE_CONFIG_ADVANCED"
fi

if [ ! -f "$FILE_CONFIG_MODULES" ]; then
    cp "$FILE_CONFIG_MODULES_EXAMPLE" "$FILE_CONFIG_MODULES"
fi

source "$FILE_CONFIG"

cd "$DIR_LIBS"
for file in *; do
    if [ $file != "init.sh" ]; then
        source "$file"
    fi
done

NETWORK_INTERFACE="$(getActiveNetworkInterface)"
NETWORK_RENDERER="$(getNetworkRenderer)"
GATEWAY="$(getGateway)"
IP_INTERNAL="$(getInternalIP)"
SUBMASK="$(getCurrentSubmaskBits $NETWORK_INTERFACE)"

MAC="$(getNetworkInterfaceMAC $NETWORK_INTERFACE)"
MAC_FORMATTED_LOWERCASE="$(echo $MAC | tr -d :)"
MAC_FORMATTED_UPPERCASE="${MAC_FORMATTED_LOWERCASE^^}"

if [ $DISTRIB_ID != "Ubuntu" ]; then
    printfCritical "EASiBox Deployer only supports Ubuntu."
    exit
fi

if [ "$DISTRIB_CODENAME" != "focal" ] && [ "$DISTRIB_CODENAME" != "jammy" ]; then
    printfWarning "Warning! This script was tested on Ubuntu 20.04 (focal) and Ubuntu 22.04 (jammy), so tweaks may be needed in your version ($DISTRIB_CODENAME)."
fi

mkdir -p "$DIR_LOGS"
echo "" > "$FILE_LOG"

cd "$DIR_BASE"

sudo clear

checkDependencies
getRemoteConfigurations

commandExists "mysql"
if [ "$?" -eq 1 ]; then
    VERSION_EASIBOX="$(sudo mysql $DATABASE_MYSQL -se "SELECT value FROM \`tbl_cash_box_config\` WHERE \`key\` = 'VERSION'")"
else
    VERSION_EASIBOX=0
fi

printfInfo "All done"

sleep 0.7
clear
sleep 0.3
